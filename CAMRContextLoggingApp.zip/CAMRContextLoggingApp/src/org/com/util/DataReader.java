package org.com.util;

public interface DataReader {
	
	    void startSampling();

	    void stopSampling();

	    float[] getSample();	

}
