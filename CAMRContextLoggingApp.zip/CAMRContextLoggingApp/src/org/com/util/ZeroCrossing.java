package org.com.util;

public class ZeroCrossing
{
    private static final String TAG = "ZeroCrossing.java";
    
    /**
     * calculate frequency using zero crossings
     */
    public static int calculate(int sampleRate, short [] sensorData)
    {
        int numSamples = sensorData.length;
        int numCrossing = 0;
        for (int p = 0; p < numSamples-1; p++)
        {
            if ((sensorData[p] > 0 && sensorData[p + 1] <= 0) || 
                (sensorData[p] < 0 && sensorData[p + 1] >= 0))
            {
                numCrossing++;
            }
        }

        float numSecondsRecorded = (float)numSamples/(float)sampleRate;
        float numCycles = numCrossing/2;
        float frequency = numCycles/numSecondsRecorded;

        return (int)frequency;
    }
}
