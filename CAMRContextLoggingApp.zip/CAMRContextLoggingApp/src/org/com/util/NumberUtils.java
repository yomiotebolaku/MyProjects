package org.com.util;

import java.math.BigDecimal;

public class NumberUtils {
    public static int clamp(int what, int low, int high) {
        if (what < low) return low;
        if (what > high) return high;
        return what;
    }
    
    public static double clamp(double what, double low, double high) {
        if (what < low) return low;
        if (what > high) return high;
        return what;
    }
    
    public static double rounded(double d, int decimalPlace){
        BigDecimal bd = new BigDecimal(Double.toString(d));
        bd = bd.setScale(decimalPlace,BigDecimal.ROUND_HALF_UP);
        return bd.doubleValue();
    } 
}
