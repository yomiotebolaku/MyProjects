package org.com.util;

import android.content.Context;

public class DataReadeFactory {	

	    public DataReader getReader(final Context context) {
	        return new RealDataReader(context);
	  
	}

}
