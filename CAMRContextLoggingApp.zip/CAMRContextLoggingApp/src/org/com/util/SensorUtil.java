package org.com.util;

import java.util.List;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorManager;

public class SensorUtil
{

    public static boolean isAccelerometerSupported(Context context)
    {
        SensorManager sm =
                (SensorManager) context
                        .getSystemService(Context.SENSOR_SERVICE);
        List<Sensor> sensors = sm.getSensorList(Sensor.TYPE_ACCELEROMETER);
        return sensors.size() > 0;
    }

    public static boolean isSupported(Context context, int sensorType)
    {
        SensorManager sm =
                (SensorManager) context
                        .getSystemService(Context.SENSOR_SERVICE);
        List<Sensor> sensors = sm.getSensorList(sensorType);
        return sensors.size() > 0;
    }
    
    

}
