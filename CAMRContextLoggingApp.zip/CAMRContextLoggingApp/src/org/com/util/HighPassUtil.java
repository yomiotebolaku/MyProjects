package org.com.util;

public class HighPassUtil {
	

	private static final float ALPHA = 0.8f;
    private static final int HIGH_PASS_MINIMUM = 10;
    private static final int MAX_SERIES_SIZE = 30;
    private float[] reading;
    
	
	public HighPassUtil() {
		super();
	}


	public float[] highPass(float x, float y, float z)
    {
        float[] filteredValues = new float[3];
        
        reading[0] = ALPHA * reading[0] + (1 - ALPHA) * x;
        reading[1] = ALPHA * reading[1] + (1 - ALPHA) * y;
        reading[2] = ALPHA * reading[2] + (1 - ALPHA) * z;

        filteredValues[0] = x - reading[0];
        filteredValues[1] = y - reading[1];
        filteredValues[2] = z - reading[2];
        
        return filteredValues;
    }

}
