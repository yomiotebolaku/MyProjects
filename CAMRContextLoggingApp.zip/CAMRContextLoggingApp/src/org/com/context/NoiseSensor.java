package org.com.context;

import java.io.FileWriter;
import java.math.BigDecimal;
import java.util.Date;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.provider.Settings.SettingNotFoundException;

public class NoiseSensor extends Thread{
	
	  private static final int FREQUENCY = 44100;
      private static final int CHANNEL = AudioFormat.CHANNEL_CONFIGURATION_MONO;
      private static final int ENCODING = AudioFormat.ENCODING_PCM_16BIT;
      
      private static final int MY_MSG = 1;
      private static final int MAXOVER_MSG = 2;
      private static final int ERROR_MSG = -1;
      private static final String TAG = "Sound Monitor";
      
      private volatile int BUFFSIZE = 0;
      private static final double P0 = 0.000002;

      private static final int CALIB_INCREMENT = 3;
      private static final int CALIB_DEFAULT = -80;
      private int mCaliberationValue = CALIB_DEFAULT;
      
      public final static int INTERVAL = 1; 

      public static boolean mIsRunning = false;
      private Handler mHandle = null;
      
      public static int brightness;

      private static double mMaxValue = 0.0;
      private volatile boolean mShowMaxValue = false;
      private static double slpvalue1 = 0.0;     
 	 	
      
      private FileWriter mSplLog = null;
      private volatile boolean mIsLogging = false;
      private static String LOGPATH ;//= "splmeter";
      private int LOGLIMIT = 50;
      private int logCount = 0;
       
      static final private Double EMA_FILTER = 0.6;
      private double mEMA = 0.0;

      public int i,peak,avg,sum,samp; 
      public static short[] buffer; //+-32767
  	public float db;
  	
  	public volatile int buflen;

      private volatile String mode = "FAST";

      AudioRecord mRecordInstance = null;
      MediaRecorder mRecorder;
      Context mContext = null;
      String PREFS_NAME = "SPLMETER";
      
      public NoiseSensor(Handler handle, Context context) {
              this.mHandle = handle;
              this.mContext = context;
              this.mCaliberationValue = readCalibValue();
              this.mode = "FAST";
              this.mIsLogging = false;
              this.mIsRunning = false;
              this.mMaxValue = 0.0;
              this.mShowMaxValue = false;
             
              
              BUFFSIZE = AudioRecord.getMinBufferSize(
                                                              FREQUENCY, 
                                                              CHANNEL, 
                                                              ENCODING);
              buflen=BUFFSIZE/2;
              
              mRecordInstance = new AudioRecord(              MediaRecorder.AudioSource.MIC,
                                                              FREQUENCY, CHANNEL, 
                                                              ENCODING, BUFFSIZE*2);
              
              BUFFSIZE = AudioRecord.getMinBufferSize(
                              FREQUENCY, 
                              CHANNEL, 
                              ENCODING)*2;
              
              LOGPATH    = Environment.getExternalStorageDirectory() + "/" + "splmeter";
      }
     
      public void reset() {
              SharedPreferences settings = PreferenceManager
                              .getDefaultSharedPreferences(mContext);
              SharedPreferences.Editor editor = settings.edit();
              editor.putInt("CalibSlow", CALIB_DEFAULT);

              editor.putInt("CalibFast", CALIB_DEFAULT);
              editor.commit();
              mCaliberationValue = CALIB_DEFAULT;
      }      
      
      /**
       * starts the engine.
       */
      public void start_engine() {
              this.mIsRunning = true;
              this.start();
      }     
      
      /**
       * stops the engine
       */
      public void stop_engine() {
      	 writeLog(slpvalue1);
              this.mIsRunning = false;
             // mRecordInstance.stop();
             // mRecordInstance.release();
              //this.stop();
      }

     
		public static int getFrequency() {
			return FREQUENCY;
		}

		public static int getBrightness() {
			return brightness;
		}

		public static double getmMaxValue() {
			return mMaxValue;
		}


		public static double getSlpvalue() {
			return  slpvalue1;
		}

      public void setMode(String mode) {
              this.mode = mode;
              setCalibValue(readCalibValue());
              
              if ("SLOW".equals(mode)) {
                      BUFFSIZE = AudioRecord.getMinBufferSize(
                                      FREQUENCY, 
                                      CHANNEL, 
                                      ENCODING)*30;                   
                      LOGLIMIT = 10;
              } else {
                      BUFFSIZE = AudioRecord.getMinBufferSize(
                                      FREQUENCY, 
                                      CHANNEL, 
                                      ENCODING)*2;                    
                      LOGLIMIT = 50;
              }
              
              
      }

      public int getCalibValue() {
              return mCaliberationValue;
      }
   
      public void setCalibValue(int value) {
              mCaliberationValue = value;
      }        
  
      public int readCalibValue() {           
              SharedPreferences settings = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_WORLD_READABLE);   
              return settings.getInt(mode, CALIB_DEFAULT);
      }

      
      
      /**
       * Stores the current calibration value to a file separate calibration for
       * SLOW and FAST modes
       */
      public void storeCalibvalue() {
              SharedPreferences settings = mContext
                                                                              .getSharedPreferences(
                                                                                              PREFS_NAME, 
                                                                                              Context.MODE_WORLD_WRITEABLE);
              SharedPreferences.Editor editor = settings.edit();
              editor.putInt(mode, mCaliberationValue);
              editor.commit();
      }

      public void calibUp() {
              mCaliberationValue = mCaliberationValue + CALIB_INCREMENT;
              if (mCaliberationValue == 0) {
                      mCaliberationValue = mCaliberationValue + 1;
              }
      }

      public void calibDown() {
              mCaliberationValue = mCaliberationValue - CALIB_INCREMENT;
              if (mCaliberationValue == 0) {
                      mCaliberationValue = mCaliberationValue - 1;
              }
      }

     
      public double showMaxValue() {
              mShowMaxValue = true;
              return mMaxValue;
      }

      
      /**
       * Get the maximum value recorded so far         
       * @return
       */
      public double getMaxValue() {
              return mMaxValue;
      }
      

      public void setMaxValue(double max) {
              mMaxValue = max;
      }

      
      /**
       * Start logging the values to a log file
       */
      public void startLogging() {
              mIsLogging = true;
      }

      
      
      /**
       * Stop the logging
       */
      public void stopLogging() {
              mIsLogging = false;
      }

      
      
      /**
       * If logging, then store the spl values to a log file. 
       * separate log file for each day.
       */
      private void writeLog(double value) {
              if (mIsLogging) {
                      if (logCount++ > LOGLIMIT) {
                              try {
                                      Date now = new Date();

                                      mSplLog = new FileWriter(LOGPATH + now.getDate() + "_"
                                                      + now.getMonth() + "_" + (now.getYear() + 1900)
                                                      + ".xls", true);
                                      mSplLog.append(value + "\n");
                                      mSplLog.close();

                              } catch (Exception e) {
                                              e.printStackTrace();
                              }
                              logCount = 0;
                      }
              }
      }

     
      @Override
		public void run() {
              try {
              	                  
                      mRecordInstance.startRecording();

                      double splValue = 0.0;
                      double rmsValue = 0.0;
                     
                      while (this.mIsRunning) {
                              
                             
                              int SIZE = BUFFSIZE;
                              short[] tempBuffer = new short[SIZE];
                              
                              mRecordInstance.read(tempBuffer, 0, SIZE);
                            
	        				  try {
	        					
	        		        	brightness = android.provider.Settings.System.getInt(mContext.getContentResolver(), android.provider.Settings.System.SCREEN_BRIGHTNESS);
	        				} catch (SettingNotFoundException e) {
	        					// TODO Auto-generated catch block
	        					e.printStackTrace();
	        				}
	        				  
                              
                              for (int i = 0; i < SIZE - 1; i++) {
                                      rmsValue += tempBuffer[i] * tempBuffer[i];
                              }
                              rmsValue = rmsValue / SIZE;
                              rmsValue = Math.sqrt(rmsValue);

                              splValue = 20 * Math.log10(rmsValue / P0);
                              splValue = splValue + mCaliberationValue;                               
                              splValue= EMA_FILTER * splValue + (1.0 - EMA_FILTER) * mEMA;
                              splValue = round(splValue, 2);
                              slpvalue1 = round(splValue,2);

                              if (mMaxValue < splValue) {
                                      mMaxValue = splValue;
                              }

                              if (!mShowMaxValue) {
                                      Message msg = mHandle.obtainMessage(MY_MSG, splValue);
                                      mHandle.sendMessage(msg);
                              } else {
                                      Message msg = mHandle.obtainMessage(MY_MSG, mMaxValue);
                                      mHandle.sendMessage(msg);
                                      Thread.sleep(2000);
                                      msg = mHandle.obtainMessage(MAXOVER_MSG, mMaxValue);
                                      mHandle.sendMessage(msg);
                                      mShowMaxValue = false;
                              }
                              
                             

                              writeLog(splValue);
                              
                              
                      }
                     
                      
          				Thread.sleep(INTERVAL*1000);
          			
              }
              catch (Exception e) {
                      e.printStackTrace();
                      Message msg = mHandle.obtainMessage(ERROR_MSG, 
                                                                      e.getLocalizedMessage()+"");
                      mHandle.sendMessage(msg);
              }
              if(mRecordInstance != null){
                      mRecordInstance.stop();
                      mRecordInstance.release();
                      mRecordInstance = null;
              }
              
      }

           public double round(double d, int decimalPlace) {
              // see the Javadoc about why we use a String in the constructor
              // http://java.sun.com/j2se/1.5.0/docs/api/java/math/BigDecimal.html#BigDecimal(double)
              BigDecimal bd = new BigDecimal(Double.toString(d));
              bd = bd.setScale(decimalPlace, BigDecimal.ROUND_HALF_UP);
              return bd.doubleValue();
      }
    

}
