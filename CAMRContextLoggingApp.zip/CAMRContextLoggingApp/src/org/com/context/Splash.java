package org.com.context;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;

public class Splash extends Activity {
	
	  @Override
	    public void onCreate(Bundle savedInstanceState)  {
	    	 super.onCreate(savedInstanceState);


	        // show the screen (our splash image)
	        setContentView(R.layout.splash);

	        // setup handler to close the splash screen
	        Handler x = new Handler();
	        x.postDelayed(new splashhandler(), 5000);
	        if (android.os.Build.VERSION.SDK_INT > 9) {
	            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
	            StrictMode.setThreadPolicy(policy);
	          }
	    }

	    class splashhandler implements Runnable {

	        @Override
			public void run() {

	            // start the context sensing main activity
	            startActivity(new Intent(getApplication(), MainActivity.class));
	            // close out this activity
	            finish();

	        }
	    }

}
