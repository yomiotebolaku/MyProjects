package org.com.context;

public class Point
{
    private double latitude;
    private double longitude;
    private float accuracy;
    private long time;
    private String provider;
    private String activity;
    
    private  double accX;
    private  double accY;
    private  double accZ;
    private  double orX;
    private  double orY;
    private  double orZ;  
    
    //Gyroscope
    private  double gyX;
    private  double gyY;
    private  double gyZ;
    //Linear Accelerometer
    private  double laccX;
    private  double laccY;
    private  double laccZ;
    //Rotation Sensor
    private  double rX;
    private  double rY;
    private  double rZ;
    //Gravity Sensor
    private  double gX;
    private  double gY;
    private  double gZ;
    
    private  double mX;
    private  double mY;
    private  double mZ;
    
    private  double lux;
    
    private double soundpressure;
    
    private double  proximity;
    
    private double  temperature;
    
    private String location;
    
    private String timeStamp ;
    
    private double altitude;
    private double bearing;
    
    private double speed;
    
    private  double mag;
    private  double grav;
    private  double rotate;
    private  double linear;
    private  double orient;
    private  double accele;
    
    private String withPeople;
    
    private String travelledOutside;
    private  String noiseLevel;
    private  String illumination;
    
    private  long acceTimestamp;
    private  long linearAcceTimestamp;
    private  long lightTimestamp;
    private  long gyroTimestamp;
    private  long magTimestamp;
    private  long proximityTimestamp;
    private  long rotationTimestamp;
    private  long gravityTimestamp;
    private  long orientationTimestamp;
    private  long tempTimestamp;
    
    private  long soundTimestamp;

    public double getLatitude()
    {
    	
        return latitude;
    }
    

    public double getMag() {
		return mag;
	}


	public void setMag(double mag) {
		this.mag = mag;
	}


	public double getGrav() {
		return grav;
	}


	public void setGrav(double grav) {
		this.grav = grav;
	}


	public double getRotate() {
		return rotate;
	}


	public void setRotate(double rotate) {
		this.rotate = rotate;
	}


	public String getNoiseLevel() {
		return noiseLevel;
	}


	public void setNoiseLevel(String noiseLevel) {
		this.noiseLevel = noiseLevel;
	}


	public String getIllumination() {
		return illumination;
	}


	public void setIllumination(String illumination) {
		this.illumination = illumination;
	}


	public double getLinear() {
		return linear;
	}


	public void setLinear(double linear) {
		this.linear = linear;
	}


	public double getOrient() {
		return orient;
	}


	public void setOrient(double orient) {
		this.orient = orient;
	}


	public double getAccele() {
		return accele;
	}


	public void setAccele(double accele) {
		this.accele = accele;
	}


	public void setLatitude(double latitude)
    {
        this.latitude = latitude;
    }

    public double getLongitude()
    {
        return longitude;
    }

    public String getTimeStamp() {
		return timeStamp;
	}

	public String isWithPeople() {
		return withPeople;
	}

	public void setWithPeople(String withPeople) {
		this.withPeople = withPeople;
	}

	public double getAltitude() {
		return altitude;
	}

	public void setAltitude(double altitude) {
		this.altitude = altitude;
	}

	public String getTravelledOutside() {
		return travelledOutside;
	}

	public void setTravelledOutside(String travelledOutside) {
		this.travelledOutside = travelledOutside;
	}

	public double getBearing() {
		return bearing;
	}

	public double getSpeed() {
		return speed;
	}

	public void setSpeed(double speed) {
		this.speed = speed;
	}

	public String getWithPeople() {
		return withPeople;
	}

	public void setBearing(double bearing) {
		this.bearing = bearing;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	public void setLongitude(double longitude)
    {
        this.longitude = longitude;
    }

    public float getAccuracy()
    {
        return accuracy;
    }

    public void setAccuracy(float accuracy)
    {
        this.accuracy = accuracy;
    }

    

    public void setTime(String timeStamp)
    {
        this.timeStamp = timeStamp;
    }

    public String getProvider()
    {
        return provider;
    }

    public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public void setProvider(String provider)
    {
        this.provider = provider;
    }

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public double getAccX() {
		return accX;
	}

	public void setAccX(double accX) {
		this.accX = accX;
	}

	public double getAccY() {
		return accY;
	}

	public void setAccY(double accY) {
		this.accY = accY;
	}

	public double getAccZ() {
		return accZ;
	}

	public void setAccZ(double accZ) {
		this.accZ = accZ;
	}

	public double getOrX() {
		return orX;
	}

	public void setOrX(double orX) {
		this.orX = orX;
	}

	public double getOrY() {
		return orY;
	}

	public void setOrY(double orY) {
		this.orY = orY;
	}

	public double getOrZ() {
		return orZ;
	}

	public void setOrZ(double orZ) {
		this.orZ = orZ;
	}

	public double getProximity() {
		return proximity;
	}

	public void setProximity(double proximity) {
		this.proximity = proximity;
	}

	public double getTemperature() {
		return temperature;
	}

	public void setTemperature(double temperature) {
		this.temperature = temperature;
	}

	public double getLux() {
		return lux;
	}

	public void setLux(double lux) {
		this.lux = lux;
	}

	public double getSoundpressure() {
		return soundpressure;
	}

	public void setSoundpressure(double soundpressure) {
		this.soundpressure = soundpressure;
	}

	
	public double getLaccX() {
		return laccX;
	}

	public void setLaccX(double laccX) {
		this.laccX = laccX;
	}

	public double getLaccY() {
		return laccY;
	}

	public void setLaccY(double laccY) {
		this.laccY = laccY;
	}

	public double getLaccZ() {
		return laccZ;
	}

	public void setLaccZ(double laccZ) {
		this.laccZ = laccZ;
	}

	public double getrX() {
		return rX;
	}

	public void setrX(double rX) {
		this.rX = rX;
	}

	public double getrY() {
		return rY;
	}

	public void setrY(double rY) {
		this.rY = rY;
	}

	public double getrZ() {
		return rZ;
	}

	public void setrZ(double rZ) {
		this.rZ = rZ;
	}

	public double getgX() {
		return gX;
	}

	public void setgX(double gX) {
		this.gX = gX;
	}

	public double getgY() {
		return gY;
	}

	public void setgY(double gY) {
		this.gY = gY;
	}

	public double getgZ() {
		return gZ;
	}

	public void setgZ(double gZ) {
		this.gZ = gZ;
	}

	public double getmX() {
		return mX;
	}

	public void setmX(double mX) {
		this.mX = mX;
	}

	public double getmY() {
		return mY;
	}

	public void setmY(double mY) {
		this.mY = mY;
	}

	public double getmZ() {
		return mZ;
	}

	public void setmZ(double mZ) {
		this.mZ = mZ;
	}

	public long getAcceTimestamp() {
		return acceTimestamp;
	}

	public void setAcceTimestamp(long acceTimestamp) {
		this.acceTimestamp = acceTimestamp;
	}

	public long getLinearAcceTimestamp() {
		return linearAcceTimestamp;
	}

	public void setLinearAcceTimestamp(long linearAcceTimestamp) {
		this.linearAcceTimestamp = linearAcceTimestamp;
	}

	public long getLightTimestamp() {
		return lightTimestamp;
	}

	public void setLightTimestamp(long lightTimestamp) {
		this.lightTimestamp = lightTimestamp;
	}

	public long getGyroTimestamp() {
		return gyroTimestamp;
	}

	public void setGyroTimestamp(long gyroTimestamp) {
		this.gyroTimestamp = gyroTimestamp;
	}

	public long getMagTimestamp() {
		return magTimestamp;
	}

	public void setMagTimestamp(long magTimestamp) {
		this.magTimestamp = magTimestamp;
	}

	public long getProximityTimestamp() {
		return proximityTimestamp;
	}

	public void setProximityTimestamp(long proximityTimestamp) {
		this.proximityTimestamp = proximityTimestamp;
	}

	public long getRotationTimestamp() {
		return rotationTimestamp;
	}

	public void setRotationTimestamp(long rotationTimestamp) {
		this.rotationTimestamp = rotationTimestamp;
	}

	public long getGravityTimestamp() {
		return gravityTimestamp;
	}

	public void setGravityTimestamp(long gravityTimestamp) {
		this.gravityTimestamp = gravityTimestamp;
	}

	public long getOrientationTimestamp() {
		return orientationTimestamp;
	}

	public void setOrientationTimestamp(long orientationTimestamp) {
		this.orientationTimestamp = orientationTimestamp;
	}

	public long getTempTimestamp() {
		return tempTimestamp;
	}

	public void setTempTimestamp(long tempTimestamp) {
		this.tempTimestamp = tempTimestamp;
	}

	public long getSoundTimestamp() {
		return soundTimestamp;
	}

	public void setSoundTimestamp(long soundTimestamp) {
		this.soundTimestamp = soundTimestamp;
	}


	public long getTime() {
		return time;
	}


	public double getGyX() {
		return gyX;
	}


	public void setGyX(double gyX) {
		this.gyX = gyX;
	}


	public double getGyY() {
		return gyY;
	}


	public void setGyY(double gyY) {
		this.gyY = gyY;
	}


	public double getGyZ() {
		return gyZ;
	}


	public void setGyZ(double gyZ) {
		this.gyZ = gyZ;
	}


	public void setTime(long time) {
		this.time = time;
	}
   
}


