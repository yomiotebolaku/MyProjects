package org.com.context;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
//import android.content.SharedPreferences;
//import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.os.Bundle;
import android.os.IBinder;
import android.speech.tts.TextToSpeech;
import android.util.Log;

public class GPSService extends Service 
{
	private static final String TAG = "GPSService";
	private static final boolean DEBUG_TTS = false;
	private static final boolean DEBUG = false;
	
	//private SharedPreferences prefs;
	private String CONTEXT_RESTART_INTENT = "org.com.context.restart";
	
	private static final String locationType = LocationManager.GPS_PROVIDER;
	private static LocationManager manager;
	private static LocationListener listener;

	private static boolean running = false;
	private static boolean isreliable = false;
	private static Location currentLocation = new Location(locationType);
	
	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	/** method for clients */
	public static double getLatitude() {
		return currentLocation.getLatitude();
	}

	public static double getLongitude() {
		return currentLocation.getLongitude();
	}

	public static float getSpeed() {
		if (currentLocation == null) {
			return 0;
		}
		return currentLocation.getSpeed();
	}

	
	public static double getAltitude() {
		return currentLocation.getAltitude();
	}
	
	public static float getBearing() {
		return currentLocation.getBearing();
	}
	
	public static Location getLocation() {
		return currentLocation;
	}
	
	public static boolean isReliable() {
		return isreliable;
	}
	
	@Override
	public void onCreate() {
		startService();
	}
	
	public void startService() {
		
		//getPrefs();
			
		listener = new LocationListener() {
			@Override
			public void onLocationChanged(Location location) {
				isreliable = true;
				currentLocation.set(location);
				
				if (DEBUG) {
					Log.i(TAG, "New location found: [" + location.getLongitude() + "," + location.getLatitude() + "] | Speed: [" + location.getSpeed() + "]");
				}
			}

			@Override
			public void onProviderDisabled(String provider) {
				manager.removeUpdates(this);
				if (DEBUG) {
					Log.i(TAG, locationType + ": is no longer reliable");
				}
				isreliable = false;
				if (DEBUG_TTS) {
					MainActivity .tts.speak("GPS reliability is " + String.valueOf(isreliable), TextToSpeech.QUEUE_FLUSH, null);
				}
			}

			@Override
			public void onProviderEnabled(String provider) {
				Log.i(TAG, locationType + ": is reliable");
				isreliable = true;
				if (DEBUG_TTS) {
					MainActivity .tts.speak("GPS reliability is " + String.valueOf(isreliable), TextToSpeech.QUEUE_FLUSH, null);
				}
			}
			
			@Override
			public void onStatusChanged(String provider, int status,
					Bundle extras) {
				switch (status) {
				case LocationProvider.OUT_OF_SERVICE:
				case LocationProvider.TEMPORARILY_UNAVAILABLE:
					isreliable = false;
					if (DEBUG_TTS) {
						MainActivity .tts.speak("GPS reliability is " + String.valueOf(isreliable), TextToSpeech.QUEUE_FLUSH, null);
					}
					if (DEBUG) {
						Log.i(TAG, "GPS Temporarily unavailable");
					}
					break;
				case LocationProvider.AVAILABLE:
					isreliable = true;
					if (DEBUG_TTS) {
						MainActivity .tts.speak("GPS reliability is " + String.valueOf(isreliable), TextToSpeech.QUEUE_FLUSH, null);
					}
					if (DEBUG) {
						Log.i(TAG, "GPS Available");
					}
					break;
				default:
					if (DEBUG_TTS) {
						MainActivity .tts.speak("Other GPS event detected", TextToSpeech.QUEUE_FLUSH, null);
					}
					if (DEBUG) {
						Log.i(TAG, "GPS State unkown");
					}
				}
				
			}
		};
		manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
		currentLocation = manager.getLastKnownLocation(locationType);
		manager.requestLocationUpdates(locationType, 0, 0, listener);
		
		IntentFilter restartFilter = new IntentFilter();
		restartFilter.addAction(CONTEXT_RESTART_INTENT);
		registerReceiver(restartIntentReceiver, restartFilter);
		
		running = true;
	}

	public  void stopService() {
		//PreferenceManager.getDefaultSharedPreferences(this).unregisterOnSharedPreferenceChangeListener(this);
		unregisterReceiver(restartIntentReceiver);
		manager.removeUpdates(listener);
		stopSelf();
		running = false;
	}
	
	BroadcastReceiver restartIntentReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			Log.d(TAG, TAG + "Restart Intent: " + intent.getAction());
			if (running) {
				stopService();
			}
			startService();
		}
	};
	

	@Override
	public int onStartCommand(Intent intent, int flags, int startId)
	{
		if (DEBUG) {
			Log.i(TAG, "Service has been started");
		}
		return 0;
	}

	@Override
	public void onDestroy()
	{
		stopService();
		if (DEBUG) {
			Log.i("GPS", "Stopping the service");
		}
		manager.removeUpdates(listener);
		stopSelf();
	}
}

	