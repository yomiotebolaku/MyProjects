package org.com.context;

import android.util.Log;

public class NoiseLevelSensor  implements AudioClipListener{

	private static final String TAG = "LoudNoiseDetector";

    private double volumeThreshold;

    public static final int DEFAULT_LOUDNESS_THRESHOLD = 2000;

    private static final boolean DEBUG = true;

    public NoiseLevelSensor()
    {
        volumeThreshold = DEFAULT_LOUDNESS_THRESHOLD;
    }

    public NoiseLevelSensor(double volumeThreshold)
    {
        this.volumeThreshold = volumeThreshold;
    }   

    private double rootMeanSquared(short[] nums)
    {
        double ms = 0;
        for (int i = 0; i < nums.length; i++)
        {
            ms += nums[i] * nums[i];
        }
        ms /= nums.length;
        return Math.sqrt(ms);
    }

	@Override
	public boolean heard(short[] data, int sampleRate) {
		boolean heard = false;
        double currentVolume = rootMeanSquared(data);
        if (DEBUG)
        {
            Log.d(TAG, "current: " + currentVolume + " threshold: "
                    + volumeThreshold);
        }

        if (currentVolume > volumeThreshold)
        {
            Log.d(TAG, "heard");
            heard = true;
        }

        return heard;		
	}
	
	public double getnoiseVolume(short[] data, int sampleRate)
	{
		
		 return  rootMeanSquared(data);
	}

}
