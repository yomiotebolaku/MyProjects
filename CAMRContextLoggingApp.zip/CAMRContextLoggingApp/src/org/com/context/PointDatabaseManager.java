package org.com.context;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
//import android.location.Location;
import android.util.Log;

public class PointDatabaseManager
{
    private static final String TAG = "ActivityDatabaseManager";
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "ActivityTracking.sqlite";
    private static final String TABLE_POINTS = "points";
    
    public static final String COLUMN_LATITUDE = "latitude";
    public static final String COLUMN_LONGITUDE = "longitude";
    public static final String COLUMN_ACCURACY = "accuracy";
    public static final String COLUMN_TIME = "time";
    public static final String COLUMN_PROVIDER = "provider";
    
    public static final String COLUMN_ORX = "orX";
    public static final String COLUMN_ORY = "orY";
    public static final String COLUMN_ORZ = "orZ";
    
    public static final String COLUMN_GYX = "gyX";
    public static final String COLUMN_GYY = "gyY";
    public static final String COLUMN_GYZ = "gyZ";
    
    public static final String COLUMN_ACCX = "accX";
    public static final String COLUMN_ACCY = "accY";
    public static final String COLUMN_ACCZ = "accZ";
    
    public static final String COLUMN_TEMPERATURE = "temperature";
    public static final String COLUMN_ILLUMINATION = "lux";
    public static final String COLUMN_NOISE = "soundLevel";
    public static final String COLUMN_LOCATION_LABEL = "location";
    public static final String COLUMN_ACTIVITY = "activity";
    public static final String ACTIVITY_TABLE_NAME = "ACTIVITY";
    
   
    private static PointDatabaseManager instance;
    
    private DatabaseHelper databaseHelper;
    private SQLiteDatabase database;
    
    private PointDatabaseManager(Context context)
    {
        databaseHelper = new DatabaseHelper(context.getApplicationContext());
        database = databaseHelper.getWritableDatabase();
    }

    public static synchronized PointDatabaseManager getInstance(Context context)
    {
        if (instance == null)
        {
            instance = new PointDatabaseManager(context.getApplicationContext());
        }
        
        return instance;
    }

    public long insertPoint(Point point)
    {
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_LOCATION_LABEL, point.getLocation());
        contentValues.put(COLUMN_ACTIVITY, point.getActivity());
        contentValues.put(COLUMN_LATITUDE, point.getLatitude());
        contentValues.put(COLUMN_LONGITUDE, point.getLongitude());
        contentValues.put(COLUMN_ACCURACY, point.getAccuracy());
        contentValues.put(COLUMN_TIME, point.getTimeStamp());
        contentValues.put(COLUMN_PROVIDER, point.getProvider());
        contentValues.put(COLUMN_PROVIDER, point.getAccuracy());
        contentValues.put(COLUMN_PROVIDER, point.getAltitude());
        contentValues.put(COLUMN_ORX, point.getOrX());
        contentValues.put(COLUMN_ORY, point.getOrY());
        contentValues.put(COLUMN_ORZ, point.getOrZ());
        contentValues.put(COLUMN_GYX, point.getGyX());
        contentValues.put(COLUMN_GYY, point.getGyY());
        contentValues.put(COLUMN_GYZ, point.getGyZ());
        contentValues.put(COLUMN_ACCX , point.getAccX());
        contentValues.put(COLUMN_ACCY, point.getAccY());
        contentValues.put(COLUMN_ACCZ, point.getAccZ());
        contentValues.put(COLUMN_TEMPERATURE, point.getTemperature());
        contentValues.put(COLUMN_ILLUMINATION, point.getLux());
        contentValues.put(COLUMN_NOISE, point.getSoundpressure());
        
        return database.insert(ACTIVITY_TABLE_NAME , null, contentValues);
    }


    public Cursor getPointCursor(String[] columns, String selection, String[] selectionArgs, String orderBy)
    {
        return database.query(TABLE_POINTS, columns, selection, selectionArgs, null, null, orderBy);
    }

    public Point retrieveLatestPoint()
    {
        final String[] columns = { COLUMN_LOCATION_LABEL,COLUMN_ACTIVITY,COLUMN_LATITUDE,
                COLUMN_LONGITUDE,
                COLUMN_ACCURACY,
                COLUMN_TIME,
                COLUMN_PROVIDER,
                COLUMN_ORX,
                COLUMN_ORY,
                COLUMN_ORZ,
                COLUMN_ACCX,
                COLUMN_ACCY,
                COLUMN_ACCZ,
                COLUMN_GYX,
                COLUMN_GYY,
                COLUMN_GYZ,
                COLUMN_TEMPERATURE,
                COLUMN_ILLUMINATION,
                COLUMN_NOISE};
        
        Cursor cursor = database.query(TABLE_POINTS, columns, null, null, null, null, "time DESC", "1");
        Point point;
        
        try
        {
            if (cursor.getCount() > 0)
            {
                cursor.moveToFirst();
                
                point = new Point();
                point.setLatitude(cursor.getDouble(cursor.getColumnIndex(COLUMN_LOCATION_LABEL)));
                point.setLatitude(cursor.getDouble(cursor.getColumnIndex(COLUMN_ACTIVITY)));
                point.setLatitude(cursor.getDouble(cursor.getColumnIndex(COLUMN_LATITUDE)));
                point.setLongitude(cursor.getDouble(cursor.getColumnIndex(COLUMN_LONGITUDE)));
                point.setAccuracy(cursor.getFloat(cursor.getColumnIndex(COLUMN_ACCURACY)));
                point.setTimeStamp(cursor.getString(cursor.getColumnIndex(COLUMN_TIME)));
                point.setAccuracy(cursor.getFloat(cursor.getColumnIndex(COLUMN_ACCURACY)));
                point.setProvider(cursor.getString(cursor.getColumnIndex(COLUMN_PROVIDER)));
                point.setProvider(cursor.getString(cursor.getColumnIndex(COLUMN_ORX)));
                point.setProvider(cursor.getString(cursor.getColumnIndex(COLUMN_ORY)));
                point.setProvider(cursor.getString(cursor.getColumnIndex(COLUMN_ORZ)));
                point.setProvider(cursor.getString(cursor.getColumnIndex(COLUMN_ACCX)));
                point.setProvider(cursor.getString(cursor.getColumnIndex(COLUMN_ACCY)));
                point.setProvider(cursor.getString(cursor.getColumnIndex(COLUMN_ACCZ)));
                point.setProvider(cursor.getString(cursor.getColumnIndex(COLUMN_GYX)));
                point.setProvider(cursor.getString(cursor.getColumnIndex(COLUMN_GYY)));
                point.setProvider(cursor.getString(cursor.getColumnIndex(COLUMN_GYZ)));
                point.setProvider(cursor.getString(cursor.getColumnIndex(COLUMN_TEMPERATURE)));
                point.setProvider(cursor.getString(cursor.getColumnIndex(COLUMN_ILLUMINATION)));
                point.setProvider(cursor.getString(cursor.getColumnIndex(COLUMN_NOISE)));
                
            }
            else
            {
                point = null;
            }
        }
        catch (Exception e)
        {
            Log.e(TAG, "Caught exception, e");
            point = null;
        }
        finally
        {
            cursor.close();
        }
        
        return point;
    }

    public void deletePoints()
    {
        database.delete(TABLE_POINTS, null, null);
    }

    public void close()
    {
        synchronized (PointDatabaseManager.class)
        {
            databaseHelper.close();
            instance = null;
            database = null;
        }
    }

    private static final class DatabaseHelper extends SQLiteOpenHelper
    {
        public DatabaseHelper(Context context)
        {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db)
        {
            db.execSQL("CREATE TABLE " +
            		"points (_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
            		"location TEXT, " +
            		"activity TEXT, " +
            		"latitude REAL, " +
            		"longitude REAL, " +            		
            		"accuracy REAL, " +
            		"altitude REAL, " +
            		"bearing REAL, " +
            		"orX REAL, " +
            		"orY REAL, " +
            		"orZ REAL, " +
            		"accX REAL, " +
            		"accY REAL, " +
            		"accZ REAL, " +
            		"gyX REAL,"+
            		"gyY REAL,"+
            		"gyZ REAL,"+
            		"temperature REAL, " +
            		"lux REAL, " +
            		"soundLevel REAL, " +
            		"time INTEGER, " +
            		
            		"provider TEXT);");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
        {
            db.execSQL("DROP TABLE IF EXISTS points;");
        }
    }
}
