package org.com.context;

public class FeaturePoint {
	
	private  double minaccX;
    private  double minaccY;
    private  double minaccZ;
    private  double stdaccX;
    private  double stdaccY;
    private  double stdaccZ;
    private  double maxaccX;
    private  double maxaccY;
    private  double maxaccZ;
    private  double avgaccX;
    private  double avgaccY;
    private  double avgaccZ;
    private  double accele;
    private  double minaccele;
    private  double maxaccele;
    private  double stdaccele; 
    private  double minorX;
    private  double minorY;
    private  double minorZ;
    private  double stdorX;
    private  double stdorY;
    private  double stdorZ;
    private  double maxorX;
    private  double maxorY;
    private  double maxorZ;
    private  double avgorX;
    private  double avgorY;
    private  double avgorZ;
    private  double orient;
    private  double minorient;
    private  double maxorient;
    private  double stdorient;
    private  double avgorient;
    
    private  double minlaccX;
    private  double minlaccY;
    private  double minlaccZ;
    private  double stdlaccX;
    private  double stdlaccY;
    private  double stdlaccZ;
    private  double maxlaccX;
    private  double maxlaccY;
    private  double maxlaccZ;
    private  double avglaccX;
    private  double avglaccY;
    private  double avglaccZ;
    private  double linear;
    private  double minlinear;
    private  double maxlinear;
    private  double stdlinear;
    private  double avglinear;
    
    private  double minrX;
    private  double minrY;
    private  double minrZ;
    private  double stdrX;
    private  double stdrY;
    private  double stdrZ;
    private  double maxrX;
    private  double maxrY;
    private  double maxrZ;
    private  double avgrX;
    private  double avgrY;
    private  double avgrZ;
    private  double rotate;
    private  double minrotate;
    private  double maxrotate;
    private  double avgrotate;
    private  double stdrotate;
    
    private  double mingX;
    private  double mingY;
    private  double mingZ;
    private  double stdgX;
    private  double stdgY;
    private  double stdgZ;
    private  double maxX;
    private  double maxY;
    private  double maxZ;
    private  double avgX;
    private  double avggY;
    private  double avggZ;
    
    private  double grav;
    private  double mingrav;
    private  double maxgrav;
    private  double avggrav;
    private  double stdgrav;
    
    private  double minmX;
    private  double minmY;
    private  double minmZ;
    private  double stdmX;
    private  double stdmY;
    private  double stdmZ;
    private  double maxmX;
    private  double maxmY;
    private  double maxmZ;
    private  double avgmX;
    private  double avgmY;
    private  double avgmZ;
    private  double mag;
    private  double minmag;
    private  double maxmag;
    private  double avgmag;
    private  double stdmag;
    
    
    private  double soundpressure;
    private double minsoundpressure;
    private  double maxsoundpressure;
    private  double avgsoundpressure;
    private  double stdsoundpressure;
    
    private static double lux;
    
    private  double minlux;
    private double maxlux;
    private  double stdlux;
    private  double avglux;
	public double getMinaccX() {
		return minaccX;
	}
	public void setMinaccX(double minaccX) {
		this.minaccX = minaccX;
	}
	public double getMinaccY() {
		return minaccY;
	}
	public void setMinaccY(double minaccY) {
		this.minaccY = minaccY;
	}
	public double getMinaccZ() {
		return minaccZ;
	}
	public void setMinaccZ(double minaccZ) {
		this.minaccZ = minaccZ;
	}
	public double getStdaccX() {
		return stdaccX;
	}
	public void setStdaccX(double stdaccX) {
		this.stdaccX = stdaccX;
	}
	public double getStdaccY() {
		return stdaccY;
	}
	public void setStdaccY(double stdaccY) {
		this.stdaccY = stdaccY;
	}
	public double getStdaccZ() {
		return stdaccZ;
	}
	public void setStdaccZ(double stdaccZ) {
		this.stdaccZ = stdaccZ;
	}
	public double getMaxaccX() {
		return maxaccX;
	}
	public void setMaxaccX(double maxaccX) {
		this.maxaccX = maxaccX;
	}
	public double getMaxaccY() {
		return maxaccY;
	}
	public void setMaxaccY(double maxaccY) {
		this.maxaccY = maxaccY;
	}
	public double getMaxaccZ() {
		return maxaccZ;
	}
	public void setMaxaccZ(double maxaccZ) {
		this.maxaccZ = maxaccZ;
	}
	public double getAvgaccX() {
		return avgaccX;
	}
	public void setAvgaccX(double avgaccX) {
		this.avgaccX = avgaccX;
	}
	public double getAvgaccY() {
		return avgaccY;
	}
	public void setAvgaccY(double avgaccY) {
		this.avgaccY = avgaccY;
	}
	public double getAvgaccZ() {
		return avgaccZ;
	}
	public void setAvgaccZ(double avgaccZ) {
		this.avgaccZ = avgaccZ;
	}
	public double getAccele() {
		return accele;
	}
	public void setAccele(double accele) {
		this.accele = accele;
	}
	public double getMinaccele() {
		return minaccele;
	}
	public void setMinaccele(double minaccele) {
		this.minaccele = minaccele;
	}
	public double getMaxaccele() {
		return maxaccele;
	}
	public void setMaxaccele(double maxaccele) {
		this.maxaccele = maxaccele;
	}
	public double getStdaccele() {
		return stdaccele;
	}
	public void setStdaccele(double stdaccele) {
		this.stdaccele = stdaccele;
	}
	public double getMinorX() {
		return minorX;
	}
	public void setMinorX(double minorX) {
		this.minorX = minorX;
	}
	public double getMinorY() {
		return minorY;
	}
	public void setMinorY(double minorY) {
		this.minorY = minorY;
	}
	public double getMinorZ() {
		return minorZ;
	}
	public void setMinorZ(double minorZ) {
		this.minorZ = minorZ;
	}
	public double getStdorX() {
		return stdorX;
	}
	public void setStdorX(double stdorX) {
		this.stdorX = stdorX;
	}
	public double getStdorY() {
		return stdorY;
	}
	public void setStdorY(double stdorY) {
		this.stdorY = stdorY;
	}
	public double getStdorZ() {
		return stdorZ;
	}
	public void setStdorZ(double stdorZ) {
		this.stdorZ = stdorZ;
	}
	public double getMaxorX() {
		return maxorX;
	}
	public void setMaxorX(double maxorX) {
		this.maxorX = maxorX;
	}
	public double getMaxorY() {
		return maxorY;
	}
	public void setMaxorY(double maxorY) {
		this.maxorY = maxorY;
	}
	public double getMaxorZ() {
		return maxorZ;
	}
	public void setMaxorZ(double maxorZ) {
		this.maxorZ = maxorZ;
	}
	public double getAvgorX() {
		return avgorX;
	}
	public void setAvgorX(double avgorX) {
		this.avgorX = avgorX;
	}
	public double getAvgorY() {
		return avgorY;
	}
	public void setAvgorY(double avgorY) {
		this.avgorY = avgorY;
	}
	public double getAvgorZ() {
		return avgorZ;
	}
	public void setAvgorZ(double avgorZ) {
		this.avgorZ = avgorZ;
	}
	public double getOrient() {
		return orient;
	}
	public void setOrient(double orient) {
		this.orient = orient;
	}
	public double getMinorient() {
		return minorient;
	}
	public void setMinorient(double minorient) {
		this.minorient = minorient;
	}
	public double getMaxorient() {
		return maxorient;
	}
	public void setMaxorient(double maxorient) {
		this.maxorient = maxorient;
	}
	public double getStdorient() {
		return stdorient;
	}
	public void setStdorient(double stdorient) {
		this.stdorient = stdorient;
	}
	public double getAvgorient() {
		return avgorient;
	}
	public void setAvgorient(double avgorient) {
		this.avgorient = avgorient;
	}
	public double getMinlaccX() {
		return minlaccX;
	}
	public void setMinlaccX(double minlaccX) {
		this.minlaccX = minlaccX;
	}
	public double getMinlaccY() {
		return minlaccY;
	}
	public void setMinlaccY(double minlaccY) {
		this.minlaccY = minlaccY;
	}
	public double getMinlaccZ() {
		return minlaccZ;
	}
	public void setMinlaccZ(double minlaccZ) {
		this.minlaccZ = minlaccZ;
	}
	public double getStdlaccX() {
		return stdlaccX;
	}
	public void setStdlaccX(double stdlaccX) {
		this.stdlaccX = stdlaccX;
	}
	public double getStdlaccY() {
		return stdlaccY;
	}
	public void setStdlaccY(double stdlaccY) {
		this.stdlaccY = stdlaccY;
	}
	public double getStdlaccZ() {
		return stdlaccZ;
	}
	public void setStdlaccZ(double stdlaccZ) {
		this.stdlaccZ = stdlaccZ;
	}
	public double getMaxlaccX() {
		return maxlaccX;
	}
	public void setMaxlaccX(double maxlaccX) {
		this.maxlaccX = maxlaccX;
	}
	public double getMaxlaccY() {
		return maxlaccY;
	}
	public void setMaxlaccY(double maxlaccY) {
		this.maxlaccY = maxlaccY;
	}
	public double getMaxlaccZ() {
		return maxlaccZ;
	}
	public void setMaxlaccZ(double maxlaccZ) {
		this.maxlaccZ = maxlaccZ;
	}
	public double getAvglaccX() {
		return avglaccX;
	}
	public void setAvglaccX(double avglaccX) {
		this.avglaccX = avglaccX;
	}
	public double getAvglaccY() {
		return avglaccY;
	}
	public void setAvglaccY(double avglaccY) {
		this.avglaccY = avglaccY;
	}
	public double getAvglaccZ() {
		return avglaccZ;
	}
	public void setAvglaccZ(double avglaccZ) {
		this.avglaccZ = avglaccZ;
	}
	public double getLinear() {
		return linear;
	}
	public void setLinear(double linear) {
		this.linear = linear;
	}
	public double getMinlinear() {
		return minlinear;
	}
	public void setMinlinear(double minlinear) {
		this.minlinear = minlinear;
	}
	public double getMaxlinear() {
		return maxlinear;
	}
	public void setMaxlinear(double maxlinear) {
		this.maxlinear = maxlinear;
	}
	public double getStdlinear() {
		return stdlinear;
	}
	public void setStdlinear(double stdlinear) {
		this.stdlinear = stdlinear;
	}
	public double getAvglinear() {
		return avglinear;
	}
	public void setAvglinear(double avglinear) {
		this.avglinear = avglinear;
	}
	public double getMinrX() {
		return minrX;
	}
	public void setMinrX(double minrX) {
		this.minrX = minrX;
	}
	public double getMinrY() {
		return minrY;
	}
	public void setMinrY(double minrY) {
		this.minrY = minrY;
	}
	public double getMinrZ() {
		return minrZ;
	}
	public void setMinrZ(double minrZ) {
		this.minrZ = minrZ;
	}
	public double getStdrX() {
		return stdrX;
	}
	public void setStdrX(double stdrX) {
		this.stdrX = stdrX;
	}
	public double getStdrY() {
		return stdrY;
	}
	public void setStdrY(double stdrY) {
		this.stdrY = stdrY;
	}
	public double getStdrZ() {
		return stdrZ;
	}
	public void setStdrZ(double stdrZ) {
		this.stdrZ = stdrZ;
	}
	public double getMaxrX() {
		return maxrX;
	}
	public void setMaxrX(double maxrX) {
		this.maxrX = maxrX;
	}
	public double getMaxrY() {
		return maxrY;
	}
	public void setMaxrY(double maxrY) {
		this.maxrY = maxrY;
	}
	public double getMaxrZ() {
		return maxrZ;
	}
	public void setMaxrZ(double maxrZ) {
		this.maxrZ = maxrZ;
	}
	public double getAvgrX() {
		return avgrX;
	}
	public void setAvgrX(double avgrX) {
		this.avgrX = avgrX;
	}
	public double getAvgrY() {
		return avgrY;
	}
	public void setAvgrY(double avgrY) {
		this.avgrY = avgrY;
	}
	public double getAvgrZ() {
		return avgrZ;
	}
	public void setAvgrZ(double avgrZ) {
		this.avgrZ = avgrZ;
	}
	public double getRotate() {
		return rotate;
	}
	public void setRotate(double rotate) {
		this.rotate = rotate;
	}
	public double getMinrotate() {
		return minrotate;
	}
	public void setMinrotate(double minrotate) {
		this.minrotate = minrotate;
	}
	public double getMaxrotate() {
		return maxrotate;
	}
	public void setMaxrotate(double maxrotate) {
		this.maxrotate = maxrotate;
	}
	public double getAvgrotate() {
		return avgrotate;
	}
	public void setAvgrotate(double avgrotate) {
		this.avgrotate = avgrotate;
	}
	public double getStdrotate() {
		return stdrotate;
	}
	public void setStdrotate(double stdrotate) {
		this.stdrotate = stdrotate;
	}
	public double getMingX() {
		return mingX;
	}
	public void setMingX(double mingX) {
		this.mingX = mingX;
	}
	public double getMingY() {
		return mingY;
	}
	public void setMingY(double mingY) {
		this.mingY = mingY;
	}
	public double getMingZ() {
		return mingZ;
	}
	public void setMingZ(double mingZ) {
		this.mingZ = mingZ;
	}
	public double getStdgX() {
		return stdgX;
	}
	public void setStdgX(double stdgX) {
		this.stdgX = stdgX;
	}
	public double getStdgY() {
		return stdgY;
	}
	public void setStdgY(double stdgY) {
		this.stdgY = stdgY;
	}
	public double getStdgZ() {
		return stdgZ;
	}
	public void setStdgZ(double stdgZ) {
		this.stdgZ = stdgZ;
	}
	public double getMaxX() {
		return maxX;
	}
	public void setMaxX(double maxX) {
		this.maxX = maxX;
	}
	public double getMaxY() {
		return maxY;
	}
	public void setMaxY(double maxY) {
		this.maxY = maxY;
	}
	public double getMaxZ() {
		return maxZ;
	}
	public void setMaxZ(double maxZ) {
		this.maxZ = maxZ;
	}
	public double getAvgX() {
		return avgX;
	}
	public void setAvgX(double avgX) {
		this.avgX = avgX;
	}
	public double getAvggY() {
		return avggY;
	}
	public void setAvggY(double avggY) {
		this.avggY = avggY;
	}
	public double getAvggZ() {
		return avggZ;
	}
	public void setAvggZ(double avggZ) {
		this.avggZ = avggZ;
	}
	public double getGrav() {
		return grav;
	}
	public void setGrav(double grav) {
		this.grav = grav;
	}
	public double getMingrav() {
		return mingrav;
	}
	public void setMingrav(double mingrav) {
		this.mingrav = mingrav;
	}
	public double getMaxgrav() {
		return maxgrav;
	}
	public void setMaxgrav(double maxgrav) {
		this.maxgrav = maxgrav;
	}
	public double getAvggrav() {
		return avggrav;
	}
	public void setAvggrav(double avggrav) {
		this.avggrav = avggrav;
	}
	public double getStdgrav() {
		return stdgrav;
	}
	public void setStdgrav(double stdgrav) {
		this.stdgrav = stdgrav;
	}
	public double getMinmX() {
		return minmX;
	}
	public void setMinmX(double minmX) {
		this.minmX = minmX;
	}
	public double getMinmY() {
		return minmY;
	}
	public void setMinmY(double minmY) {
		this.minmY = minmY;
	}
	public double getMinmZ() {
		return minmZ;
	}
	public void setMinmZ(double minmZ) {
		this.minmZ = minmZ;
	}
	public double getStdmX() {
		return stdmX;
	}
	public void setStdmX(double stdmX) {
		this.stdmX = stdmX;
	}
	public double getStdmY() {
		return stdmY;
	}
	public void setStdmY(double stdmY) {
		this.stdmY = stdmY;
	}
	public double getStdmZ() {
		return stdmZ;
	}
	public void setStdmZ(double stdmZ) {
		this.stdmZ = stdmZ;
	}
	public double getMaxmX() {
		return maxmX;
	}
	public void setMaxmX(double maxmX) {
		this.maxmX = maxmX;
	}
	public double getMaxmY() {
		return maxmY;
	}
	public void setMaxmY(double maxmY) {
		this.maxmY = maxmY;
	}
	public double getMaxmZ() {
		return maxmZ;
	}
	public void setMaxmZ(double maxmZ) {
		this.maxmZ = maxmZ;
	}
	public double getAvgmX() {
		return avgmX;
	}
	public void setAvgmX(double avgmX) {
		this.avgmX = avgmX;
	}
	public double getAvgmY() {
		return avgmY;
	}
	public void setAvgmY(double avgmY) {
		this.avgmY = avgmY;
	}
	public double getAvgmZ() {
		return avgmZ;
	}
	public void setAvgmZ(double avgmZ) {
		this.avgmZ = avgmZ;
	}
	public double getMag() {
		return mag;
	}
	public void setMag(double mag) {
		this.mag = mag;
	}
	public double getMinmag() {
		return minmag;
	}
	public void setMinmag(double minmag) {
		this.minmag = minmag;
	}
	public double getMaxmag() {
		return maxmag;
	}
	public void setMaxmag(double maxmag) {
		this.maxmag = maxmag;
	}
	public double getAvgmag() {
		return avgmag;
	}
	public void setAvgmag(double avgmag) {
		this.avgmag = avgmag;
	}
	public double getStdmag() {
		return stdmag;
	}
	public void setStdmag(double stdmag) {
		this.stdmag = stdmag;
	}
	public double getSoundpressure() {
		return soundpressure;
	}
	public void setSoundpressure(double soundpressure) {
		this.soundpressure = soundpressure;
	}
	public double getMinsoundpressure() {
		return minsoundpressure;
	}
	public void setMinsoundpressure(double minsoundpressure) {
		this.minsoundpressure = minsoundpressure;
	}
	public double getMaxsoundpressure() {
		return maxsoundpressure;
	}
	public void setMaxsoundpressure(double maxsoundpressure) {
		this.maxsoundpressure = maxsoundpressure;
	}
	public double getAvgsoundpressure() {
		return avgsoundpressure;
	}
	public void setAvgsoundpressure(double avgsoundpressure) {
		this.avgsoundpressure = avgsoundpressure;
	}
	public double getStdsoundpressure() {
		return stdsoundpressure;
	}
	public void setStdsoundpressure(double stdsoundpressure) {
		this.stdsoundpressure = stdsoundpressure;
	}
	public static double getLux() {
		return lux;
	}
	public static void setLux(double lux) {
		FeaturePoint.lux = lux;
	}
	public double getMinlux() {
		return minlux;
	}
	public void setMinlux(double minlux) {
		this.minlux = minlux;
	}
	public double getMaxlux() {
		return maxlux;
	}
	public void setMaxlux(double maxlux) {
		this.maxlux = maxlux;
	}
	public double getStdlux() {
		return stdlux;
	}
	public void setStdlux(double stdlux) {
		this.stdlux = stdlux;
	}
	public double getAvglux() {
		return avglux;
	}
	public void setAvglux(double avglux) {
		this.avglux = avglux;
	}
    
    

}
