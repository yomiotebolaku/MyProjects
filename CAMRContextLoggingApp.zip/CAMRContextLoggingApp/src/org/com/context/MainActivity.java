	package org.com.context;

	import android.app.Activity;
	import android.app.ProgressDialog;
	import android.os.AsyncTask;
	import android.os.Bundle;
	import android.os.Environment;
	import android.preference.PreferenceManager;

	import java.io.File;
	import java.io.FileWriter;
	import java.io.IOException;
	import java.text.DecimalFormat;
	import java.util.Locale;
	import java.util.Timer;
	import java.util.TimerTask;


	import org.com.util.CSVWriter;

import android.content.Intent;
	import android.content.SharedPreferences;
	import android.content.res.Configuration;
	import android.database.Cursor;
	import android.database.SQLException;
	import android.database.sqlite.SQLiteDatabase;
	//import android.os.Bundle;
	import android.speech.tts.TextToSpeech;
	import android.speech.tts.TextToSpeech.OnInitListener;
	import android.util.Log;
	import android.view.View;
	import android.view.View.OnClickListener;
	import android.widget.AdapterView;
	
	import android.widget.ArrayAdapter;
	import android.widget.Button;
	
	import android.widget.CheckBox;
	import android.widget.Spinner;
	import android.widget.Toast;
	import android.widget.AdapterView.OnItemSelectedListener;

			public class MainActivity extends Activity implements OnInitListener  {
	        
	        private static final String tag = "Context Logger Activity";
	        
	        //private static final String activityFileName = "currentActivity.txt";
	        
	        //final static private String APP_KEY = "INSERT_APP_KEY";
	        //final static private String APP_SECRET = "INSERT_APP_SECRET";
	        
	        private static Spinner location;
	        private static Spinner user_activity;
	        
	        private static Spinner illumination;
	        private static Spinner soundLevel;
	        
	        private static String activity;
	        
	        public static TextToSpeech tts;
	        
	        public boolean ttsEnabled = true;
	        //private String currentActivity = "";
	        
	      //  private String currentActivityName = "";
	        private static String currentLocationLabel = "";
	        
	        private static boolean running = false;
	        //illumination values 5, 1000, 5000
	       // private int altitudeCorrectionMeters = 20;
	        
	        private static final char CSV_DELIM = ',';
	        
	        private ProgressDialog progressDialog;
	        
	        public static final String COLUMN_LATITUDE = "latitude";
	        public static final String COLUMN_LONGITUDE = "longitude";
	        public static final String COLUMN_ALTITUDE = "altitude";
	        public static final String COLUMN_SPEED = "speed";
	        public static final String COLUMN_BEARING = "bearing";
	        public static final String COLUMN_ACCURACY = "accuracy";
	        public static final String COLUMN_TIME = "time";
	        public static final String COLUMN_PROVIDER = "provider";
	        
	        public static final String COLUMN_LOCATION_LABEL = "location";
	        public static final String COLUMN_ACTIVITY = "activity";
	        
	        public static final String COLUMN_ORX = "orX";
	        public static final String COLUMN_ORY = "orY";
	        public static final String COLUMN_ORZ = "orZ";
	        
	        public static final String COLUMN_ACCX = "accX";
	        public static final String COLUMN_ACCY = "accY";
	        public static final String COLUMN_ACCZ = "accZ";
	        
	        public static final String COLUMN_TEMPERATURE = "temperature";
	        public static final String COLUMN_ILLUMINATION = "lux";
	        public static final String COLUMN_NOISE = "soundLevel";
	        public static final String ACTIVITYTIMESTAMP = "GMTTIMESTAMP";
	        
	        public static String userWithPeople;
	        private static long timestamp;
	        private static long lastaccess;
	        private long timeout = 2000;
	        public static String userTravelledOutsideCountry;
	        
	        Button buttonStart,buttonStop,exportButton,newActivityButton;
	        
	        static CheckBox withPeople;
	        static CheckBox travelled;
	        public static final String CONTEXT_RESTART_INTENT = "restartIntnt";
	        
	       // private final DecimalFormat sevenSigDigits = new DecimalFormat("0.#######");
	        
	        //SharedPreferences activityPrefs;
	        static SharedPreferences userIdPref;
	        
	        private static Timer timer;
	        
	        private static String illuminationLevel;
	        private static String noiseLevel;
	        
	        
	        static SharedPreferences.Editor editor ;
	        /** Called when the activity is first created. */
	        @Override
	        protected void onCreate(Bundle savedInstanceState) {		
	    		super.onCreate(savedInstanceState);
	                setContentView(R.layout.main);             
	                
	               userIdPref =  PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
					//final SharedPreferences.Editor 
	     		   	
	            buttonStart = (Button)findViewById(R.id.ButtonStart);
	            buttonStart.setOnClickListener(mStartListener);
	   	        buttonStop = (Button)findViewById(R.id.ButtonStop);
	   	        buttonStop.setOnClickListener(mStopListener);
	   	        exportButton = (Button)findViewById(R.id.ButtonExport);
	   	        exportButton.setOnClickListener(mExportListener);
	   	               // RadioButton ground = (RadioButton)findViewById(R.id.RadioGround);
	   	               // ground.setChecked(false);
	   	                //initActivityName();
	   	     newActivityButton = (Button)findViewById(R.id.ButtonNewTrip);
	   	     newActivityButton.setOnClickListener(mNewActivityListener);
	   	               
	   	     addItemtoActivitySpinner();
	   	     addItemtoLocationSpinner();	 
	   	     addItemtoIlluminationSpinner();
	   	     addItemtoSoundLevelSpinner();
	  	       
	  	        
	  	      withPeople = (CheckBox)findViewById(R.id.with_people);
	  	      withPeople.setOnClickListener(new CustomOnItemCheckedListener() );
	  	      travelled = (CheckBox)findViewById(R.id.travelledOutside);
	  	      travelled.setOnClickListener(new CustomOnTravelCheckedListener());
	  	      startService(new Intent(MainActivity.this,
	            		ContextDataService.class));   
	        }

	    @Override
			protected void onStart() {
				// TODO Auto-generated method stub
				super.onStart();
				
				
				//LocationMonitor.StartThread(locationPollFreq);
				
			}

		@Override
		protected void onPause() {
			// TODO Auto-generated method stub
			super.onPause();
			//exportdb();
			LoggData.StopThread();
			 stopService(new Intent(MainActivity.this,
	            		ContextDataService.class));
		}

		@Override
		protected void onResume() {
			// TODO Auto-generated method stub
			super.onResume();
			updateLabel();
			 startService(new Intent(MainActivity.this,
	            		ContextDataService.class));
			 super.onResume();
		}

		@Override
		protected void onStop() {
			// TODO Auto-generated method stub
		
			//exportdb();
			 stopService(new Intent(MainActivity.this,
	            		ContextDataService.class));
				super.onStop();
		}

	       private OnClickListener mStartListener = new OnClickListener() {
	        @Override
			public void onClick(View v)
	        {
	        	//ContextDataService.
	        	addListenerOnButton();
	            startService(new Intent(MainActivity.this,
	            		ContextDataService.class));
	        }
	    };

	    private OnClickListener mStopListener = new OnClickListener() {
	        @Override
			public void onClick(View v)
	        {
	        	LoggData.StopThread();
	            stopService(new Intent(MainActivity.this,
	            		ContextDataService.class));
	        }
	    };
	    
	        private OnClickListener mNewActivityListener = new OnClickListener() {
	        @Override
			public void onClick(View v)
	        {
	        	progressDialog = ProgressDialog.show(MainActivity.this, "", "Logging Context Data...");

	   		 new Thread() {

	   		 @Override
			public void run() {
	   			
	   			LoggData.StartThread(1);

	   		 try{
	   		// LoggData.StartThread(1);
	   		 sleep(3000);
	   		
	   		LoggData.StopThread();

	   		 } catch (Exception e) {

	   		 Log.e("tag", e.getMessage());

	   		 }

	   		 // dismiss the progress dialog

	   		 progressDialog.dismiss();
	   		

	   		 }

	   		 }.start();
	   		// LoggData.StopThread();

	   		 }	 
	        
	               
	        };
	    
	        @Override
	        public void onConfigurationChanged(Configuration newConfig)
	        {
	        	 super.onConfigurationChanged(newConfig);
	        }
  		 
    
	    
	    private OnClickListener mExportListener = new OnClickListener() {
	        @Override
			public void onClick(View v) {
	        	LoggData.StopThread();
	        	exportdb();
          }

	        };
	    
	         public void exportdb()
	        {
	        	try
                {
                    new ExportDatabaseCSVTask().execute("");

                }
                catch(Exception ex)
                {
                    Log.e("Error in MainActivity",ex.toString());
                }
	        }	          

	        public class ExportDatabaseCSVTask extends AsyncTask<String, Void, Boolean>
	        {
	            private final ProgressDialog dialog = new ProgressDialog(MainActivity.this);
	            @Override
	            protected void onPreExecute()

	            {
	                this.dialog.setMessage("Exporting Context database to CSV file...");
	                this.dialog.show();
	            }	            	            

	            @Override
				protected Boolean doInBackground(final String... args)
	            {
	                File dbFile=getDatabasePath(ContextDataService.DATABASE_NAME);

	                Log.i(tag, dbFile.getAbsolutePath());  // displays the database path in your logcat 
	               
	                SQLiteDatabase db = null;
	                File exportDir = null;
	                //Cursor cursor = null;
	                if(Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)){

	                exportDir = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "contextlogger");
	                }

	                if (!exportDir.exists())

	                {
	                    exportDir.mkdirs();
	                }	                   
	          
	               // SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
	                //String timeStamp = sdf.format(new Date());
	                //timeStamp+
	               // Point point = new Point();
	                
	                File file = new File(exportDir, "context_data.csv");
	               // PrintWriter printdb = new PrintWriter(file);
	               
	                try
	                {
	                    file.createNewFile();
	                    FileWriter writer = new FileWriter(file);

	                    CSVWriter csvWrite = new CSVWriter(writer);	 
	                    db = openOrCreateDatabase(ContextDataService.DATABASE_NAME, SQLiteDatabase.OPEN_READWRITE, null);
	                    
	                    Cursor cursor = db.rawQuery("select * from " + ContextDataService.ACTIVITY_TABLE_NAME +" ORDER BY _id ASC",null);
	                   	                    
	                   csvWrite.writeNext(cursor.getColumnNames());

	                    while(cursor.moveToNext())

	                    {
	                    	
	                    	 String columns[] = {cursor.getString(0),cursor.getString(1),cursor.getString(2),cursor.getString(3),cursor.getString(4),cursor.getString(5),cursor.getString(6)
		                        		,cursor.getString(7),cursor.getString(8),cursor.getString(9),cursor.getString(10),cursor.getString(11),cursor.getString(12),cursor.getString(13),cursor.getString(14)
		                        		,cursor.getString(15),cursor.getString(16),cursor.getString(17),cursor.getString(18),cursor.getString(19),cursor.getString(20),cursor.getString(21),cursor.getString(22),cursor.getString(23),
		                        		cursor.getString(24),cursor.getString(25),cursor.getString(26),cursor.getString(27),cursor.getString(28),cursor.getString(29),
		                        		cursor.getString(30),cursor.getString(31),cursor.getString(32),cursor.getString(33),cursor.getString(34),cursor.getString(35),cursor.getString(36),cursor.getString(37),cursor.getString(38),cursor.getString(39)
		                        		,cursor.getString(40),cursor.getString(41),cursor.getString(42),cursor.getString(43),cursor.getString(44),cursor.getString(45)
		                        	,cursor.getString(46),cursor.getString(47),cursor.getString(48),cursor.getString(49),cursor.getString(50)};

	                         csvWrite.writeNext(columns);	                       
	                               
	                    }
	                    
	                    csvWrite.close();

	                    cursor.close();
	                    db.close();

	                    return true;

	                }  catch(SQLException sqlEx)

	                {
	                    Log.e("MainActivity", sqlEx.getMessage(), sqlEx);
	                    Toast.makeText(getBaseContext(),
                                "...couldn't find any location points in the database ...cvs file was exported.",
                                Toast.LENGTH_LONG).show();

	                    return false;
	                }

	                catch (IOException e)
	                {
	                    Log.e("MainActivity", e.getMessage(), e);

	                    return false;
	                }

	            }	      

	            @Override
				protected void onPostExecute(final Boolean success)

	            {
	                if (this.dialog.isShowing())

	                {
	                    this.dialog.dismiss();
	                }	        
	          
	            }
	        
	       }

			@Override
			public void onInit(int arg0) {
				Locale loc = Locale.getDefault();
				if (tts.isLanguageAvailable(loc) >= TextToSpeech.LANG_AVAILABLE) {
					tts.setLanguage(loc);
				}
				if (ttsEnabled)
					tts.speak("Text to Speach Initialized", TextToSpeech.QUEUE_FLUSH,
							null);
			}
			
			static class LoggData extends TimerTask
			{
				volatile int numberOfLogs = 120;
				private static   LoggData loggDataObj = new LoggData();
				private static  Timer timer = new Timer("Logging...");
				
				@Override
				public void run() {	
				while(--numberOfLogs>=0){
					updateLabel();
					ContextDataService.insertActivity();        
		    		ContextDataService.insertPoint();    	
				}
				}
				
				public static void StartThread(int interval) {
					if (running == true) {// Analysis without numbers is only an opinion.
						return;
					} 
					else if(running == false){
					Log.i(tag, "StartLogging");
					
					timer.scheduleAtFixedRate(loggDataObj,500, interval*50);
					running = true;
					}
				
				}
				
				public static void StopThread() {
					if(running == false)
					{
						return;
					}
					else if(running == true)
					{
						Log.i(tag, "Stop() logging");
						
						loggDataObj.cancel();
						loggDataObj = new LoggData();
						//timer.cancel();
						timer.purge();
						
						running = false;
					}
				}

				
			}
				
		public void addItemtoLocationSpinner()
		{
			 MainActivity.location = (Spinner) findViewById(R.id.location);
			 ArrayAdapter<String> locations = new ArrayAdapter<String>(this, R.layout.spinnerview, getResources()
	  		            .getStringArray(R.array.location));
	     		  locations.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	  	        MainActivity.location.setAdapter(locations);
	  	      MainActivity.location.setOnItemSelectedListener(new CustomOnItemSelectedListener());
			
		}
		
		public void addItemtoActivitySpinner()
		{
			   
            MainActivity.user_activity = (Spinner) findViewById(R.id.useractivity);
            ArrayAdapter<String> activities = new ArrayAdapter<String>(this, R.layout.spinnerview, getResources()
  		            .getStringArray(R.array.useractivity));
  	        activities.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
  	        MainActivity.user_activity.setAdapter(activities);
  	      MainActivity.user_activity.setOnItemSelectedListener(new CustomOnItemSelectedListener());
			
		}		
		
		public void addItemtoIlluminationSpinner()
		{
			   
            MainActivity.illumination = (Spinner) findViewById(R.id.illumination);
            ArrayAdapter<String>lightLevel = new ArrayAdapter<String>(this, R.layout.spinnerview, getResources()
  		            .getStringArray(R.array.Illumination));
  	        lightLevel.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
  	        MainActivity.illumination.setAdapter(lightLevel);
  	      MainActivity.illumination.setOnItemSelectedListener(new CustomOnItemSelectedListener());
			
		}		
		public void addItemtoSoundLevelSpinner()
		{
			   
            MainActivity.soundLevel = (Spinner) findViewById(R.id.sound);
            ArrayAdapter<String> soundLevels = new ArrayAdapter<String>(this, R.layout.spinnerview, getResources()
  		            .getStringArray(R.array.EnviromentNoise));
  	        soundLevels.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
  	        MainActivity.soundLevel.setAdapter(soundLevels);
  	      MainActivity.soundLevel.setOnItemSelectedListener(new CustomOnItemSelectedListener());
			
		}		
		
		public void addListenerOnButton() {

			location = (Spinner) findViewById(R.id.location);
			user_activity = (Spinner) findViewById(R.id.useractivity);
			illumination = (Spinner) findViewById(R.id.illumination);
			soundLevel = (Spinner) findViewById(R.id.sound);
			withPeople = (CheckBox)findViewById(R.id.with_people);
			travelled = (CheckBox)findViewById(R.id.travelledOutside);
			activity = String.valueOf(user_activity.getSelectedItem()) ;
			currentLocationLabel = String.valueOf(location.getSelectedItem());
			illuminationLevel = String.valueOf(illumination.getSelectedItem());
			noiseLevel = String.valueOf(soundLevel.getSelectedItem());
			
			
			if(withPeople.isChecked())
			{
				userWithPeople = "Yes";
			}
			else
			{
				userWithPeople = "No";
			}	
			
			if(travelled.isChecked())
			{
				userTravelledOutsideCountry = "Yes";
			}
			else
			{
				userTravelledOutsideCountry = "No";
			}
			
			editor = userIdPref.edit();
			
			editor.putString("location", currentLocationLabel);
			editor.putString("activity", activity);
			editor.putString("withPeople", userWithPeople );
			editor.putString("travelled", userTravelledOutsideCountry);
			editor.putString("illumination",illuminationLevel);
			editor.putString("noise", noiseLevel);
			
            editor.commit();

		}
				
		public static void updateLabel()
		{
			activity = String.valueOf(user_activity.getSelectedItem()) ;
			currentLocationLabel = String.valueOf(location.getSelectedItem());
			illuminationLevel = String.valueOf(illumination.getSelectedItem());
			noiseLevel = String.valueOf(soundLevel.getSelectedItem());
			
			
			
			if(withPeople.isChecked())
			{
				userWithPeople = "Yes";
			}
			else
			{
				userWithPeople = "No";
			}	
			
			if(travelled.isChecked())
			{
				userTravelledOutsideCountry = "Yes";
			}
			else
			{
				userTravelledOutsideCountry = "No";
			}
			
			editor = userIdPref.edit();
			
			editor.putString("location", currentLocationLabel);
			editor.putString("activity", activity);
			editor.putString("withPeople", userWithPeople );
			editor.putString("travelled", userTravelledOutsideCountry);
			editor.putString("illumination",illuminationLevel);
			editor.putString("noise", noiseLevel);
			
            editor.commit();
			
		}
		
		 class CustomOnItemCheckedListener implements OnClickListener {

				@Override
				public void onClick(View v) {
					 if (((CheckBox) v).isChecked()) 
	                 {			                    	 
	                	 userWithPeople = "YES";               	

	                 }
	                 else
	                 {
	                	 userWithPeople = "NO";
	                 }
				}
				 
			 }
		 
		 class CustomOnTravelCheckedListener implements OnClickListener {

				@Override
				public void onClick(View v) {
					 if (((CheckBox) v).isChecked()) 
	                 {			                    	 
						 userTravelledOutsideCountry = "YES";               	

	                 }
	                 else
	                 {
	                	 userTravelledOutsideCountry = "NO";
	                 }
				}
				 
			 }
		 
		 class CustomOnItemSelectedListener implements OnItemSelectedListener {

				@Override
				public void onItemSelected(AdapterView<?> parent, View view, int pos,
						long id) {
					//Toast.makeText(parent.getContext(), 
							//"OnItemSelectedListener : " + parent.getItemAtPosition(pos).toString(),
							//Toast.LENGTH_SHORT).show();
				}

				@Override
				public void onNothingSelected(AdapterView<?> arg0) {
					// TODO Auto-generated method stub

				}

		 }
	 		 
		 		
}

			


				