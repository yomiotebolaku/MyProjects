package org.com.context;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.com.util.HighPassUtil;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.os.Binder;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.Toast;

public class ContextDataService extends Service implements SensorEventListener {

        public static final String DATABASE_NAME = "USERACTIVITYLOG"; //"USERACTIVITYDATABASESTORE" USERACTIVITYLOGGER
       // public static final String LOCATION_TABLE_NAME = "LOCATION_POINTS";
        public static final String ACTIVITY_TABLE_NAME = "ACTIVITY";
        private static final String THETA = "\u0398";
        private static final String ACCELERATION_UNITS = "m/s\u00B2";
        
        private static final String TAG = "ContextDataService";
        private static final int DATABASE_VERSION = 2;
        //private static final String DATABASE_NAME = "LocationTracking.sqlite";
        //private static final String TABLE_POINTS = "points";
      
        
        private boolean tempSensorsEnabled = false;
        private boolean lightSensorsEnabled = false;
        private boolean accelerometerSensorsEnabled = false;
        private boolean proximitySensorsEnabled = false;
        private boolean orientationSensorsEnabled = false;
        private boolean gravitySensorsEnabled = false;
        private boolean gyroscopeSensorsEnabled = false;
        private boolean linearAccelerometerSensorsEnabled = false;
        private boolean rotationSensorsEnabled = false;
      	private boolean magneticFieldSensorsEnabled = false;
        private static final boolean DEBUG = false;
       // public  static PointDatabaseManager dbManager;
        public static Point point = new Point();
       // private SQLiteDatabase db;
        
        private boolean running = false;
     
       // private static final float ALPHA = 0.8f;
       // private static final int HIGH_PASS_MINIMUM = 10;
       // private static final int MAX_SERIES_SIZE = 30;
        private float[] reading;
        private static final int locationPollFreq = 2;
        
        public static final String COLUMN_LATITUDE = "latitude";
        public static final String COLUMN_LONGITUDE = "longitude";
        public static final String COLUMN_ALTITUDE = "altitude";
        public static final String COLUMN_SPEED = "speed";
        public static final String COLUMN_BEARING = "bearing";
        public static final String COLUMN_ACCURACY = "accuracy";
        public static final String COLUMN_TIME = "time";
        public static final String COLUMN_PROVIDER = "provider";
        
        public static final String COLUMN_LOCATION_LABEL = "location";
        public static final String COLUMN_ACTIVITY = "activity";
        
        public static final String COLUMN_ORX = "orX";
        public static final String COLUMN_ORY = "orY";
        public static final String COLUMN_ORZ = "orZ";
        public static final String COLUMN_OR = "orient";
        
        public static final String COLUMN_RX = "rX";
        public static final String COLUMN_RY = "rY";
        public static final String COLUMN_RZ = "rZ";
        public static final String COLUMN_R = "rotate";
        
        public static final String COLUMN_GX = "gX";
        public static final String COLUMN_GY = "gY";
        public static final String COLUMN_GZ = "gZ";
        public static final String COLUMN_G = "grav";
        
        public static final String COLUMN_MX = "mX";
        public static final String COLUMN_MY = "mY";
        public static final String COLUMN_MZ = "mZ";
        public static final String COLUMN_M = "mag";
        
        public static final String COLUMN_PROXIMITY = "proximity";
        
        public static final String COLUMN_GYX = "gyX";
        public static final String COLUMN_GYY = "gyY";
        public static final String COLUMN_GYZ = "gyZ";
        
        public static final String COLUMN_ACCX = "accX";
        public static final String COLUMN_ACCY = "accY";
        public static final String COLUMN_ACCZ = "accZ";
        public static final String COLUMN_ACC = "accele";
        
        public static final String COLUMN_LACCX = "laccX";
        public static final String COLUMN_LACCY = "laccY";
        public static final String COLUMN_LACCZ = "laccZ";
        
        public static final String COLUMN_LACC = "linear";
        
        public static final String COLUMN_TEMPERATURE = "temperature";
        public static final String COLUMN_ILLUMINATION = "lux";
        public static final String COLUMN_NOISE = "soundLevel";
        public static final String ACTIVITYTIMESTAMP = "GMTTIMESTAMP";
        public static final String ILLUMINATION_LABEL = "illumination";
        public static final String NOISE_LEVEL = "noiseLevel";
        
        public static final String CONTEXT_RESTART_INTENT = "restartIntnt";
        
        private Sensor accelerometerSensor;
        private Sensor orientationSensor;
        private Sensor temperatureSensor;
        private Sensor lightSensor;
        private Sensor proximitySensor;
        private Sensor gyroscope;
        private Sensor gravity;
        private Sensor linearAccelerometer;
        private Sensor rotationSensor;
        private Sensor magneticField;
        
        PrintWriter printWriter;
       
        NoiseSensor noiseLevelSensor = null;
        
        public static Location location;
        //Accelerometer
        private static double accX;
        private static double accY;
        private static double accZ;
        private static double accele;
       // Orientation sensor
        private static double orX;
        private static double orY;
        private static double orZ;
        private static double orient;
        private static String noiseLevel;
        private static String illumination;
        //Gyroscope
        private static double gyX;
        private static double gyY;
        private static double gyZ;
        //Linear Accelerometer
        private static double laccX;
        private static double laccY;
        private static double laccZ;
        private static double linear;
        //Rotation Sensor
        private static double rX;
        private static double rY;
        private static double rZ;
        private static double rotate;
        //Gravity Sensor
        private static double gX;
        private static double gY;
        private static double gZ;
        
        private static double grav;
        //Magnetic Sensor
        private static double mX;
        private static double mY;
        private static double mZ;
        private static double mag;
        
        
        private static final String COLUMN_WITH_PEOPLE ="withPeople";
        private static final String COLUMN_TRAVEL ="travelledOutside";
        private static String withPeople;
        private static String travelledOutside;
        
        private boolean useHighPassFilter;
        
        private long startTime;
        
        private static SQLiteDatabase database;

        
        private static String accuracy;
        
        private SensorManager sm;
        static SharedPreferences userActivity ;
        
        private static double proximity;
        
        private static double temperature;
               
        private static final float ALPHA = 0.8f;
       
        private static long acceTimestamp;
        private static long linearAcceTimestamp;
        private static long lightTimestamp;
        private static long gyroTimestamp;
        private static long magTimestamp;
        private static long proximityTimestamp;
        private static long rotationTimestamp;
        private static long gravityTimestamp;
        private static long orientationTimestamp;
        private static long tempTimestamp;
        private static long soundTimestamp;
        
      public static final String  COLUMN_ACCETIME = "acceTimestamp";
      public static final String  COLUMN_LINEARACCETIME = "linearAcceTimestamp";
      public static final String  COLUMN_LIGHTTIME = "lightTimestamp";
      public static final String  COLUMN_GYROTIME = "gyroTimestamp";
      public static final String  COLUMN_MAGTIME = "magTimestamp";
     // public static final String  COLUMN_GYRO = ""
      public static final String  COLUMN_PROXITIME = "proximityTimestamp";
      public static final String  COLUMN_ROTATIONTIME = "rotationTimestamp";
      public static final String  COLUMN_GRAVITYTIME = "gravityTimestamp";
      public static final String  COLUMN_ORIENTTIME = "orientTimestamp";
      public static final String  COLUMN_TEMPTIME = "tempTimestamp";
      public static final String  COLUMN_SOUNDTIME = "soundTimestamp";

        private LocationManager lm;
       // private LocationListener locationListener;
        private static SQLiteDatabase db;
        static final int ERROR_MSG = -1;
        static final int MY_MSG = 1;
        LocationProvider provider;
        //private static NoiseMonitor soundEngine = null;
        private static double soundpressure;
              
        private static double lux;
        private static String activity;
        private static String locationLabel;
        private static String activityName;
        
        Context mContext = ContextDataService.this;
        
        private static long minTimeMillis = 2000;
        private static long minDistanceMeters = 10;
        private static float minAccuracyMeters = 35;
        
       // private int lastStatus = 0;
        private static boolean showingDebugToast = false;
        
        private static final String tag = "ContextLoggerService";
		private static final int accelPeriod = 0;

        /** Called when the activity is first created. */
       public  void startLoggerService() {

             	creatDatabase();
        		startMonitors();
        		startSensors();
                if(NoiseSensor.mIsRunning==false)
        		{
        			startSoundEngine();
        		}    	         
             
        }	
       
       public void creatDatabase()
       {
       	db = openOrCreateDatabase(DATABASE_NAME, SQLiteDatabase.OPEN_READWRITE, null);
       	
                db.execSQL("CREATE TABLE IF NOT EXISTS " +
               		ACTIVITY_TABLE_NAME +" (_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
               		"time TEXT, " +
                		"location TEXT, " +                		
                		"latitude REAL, " +
                		"longitude REAL, " +  
                		"activity TEXT," +
                		"accuracy REAL, " +
                		"altitude REAL, " +
                		"bearing REAL, " +
                		"speed REAL, " +
                		"orientTimestamp LONG, " +
                		"orX REAL, " +
                		"orY REAL, " +
                		"orZ REAL, " +                		
                		"rotationTimestamp LONG, " +
                		"rX REAL, " +
                		"rY REAL, " +
                		"rZ REAL, " +                		
                		"acceTimestamp LONG, " +
                		"accX REAL, " +
                		"accY REAL, " +
                		"accZ REAL, " +
                		"accele REAL, " +
                		"linearAcceTimestamp LONG, " +
                		"laccX REAL, " +
                		"laccY REAL, " +
                		"laccZ REAL, " + 
                		"linear REAL, " +
                		"gravityTimestamp LONG, " +
                		"gX REAL, " +
                		"gY REAL, " +
                		"gZ REAL, " +                		
                		"magTimestamp LONG, " +
                		"mX REAL, " +
                		"mY REAL, " +
                		"mZ REAL, " +   
                		"gyroTimestamp LONG, " +
                		"gyX REAL, " +
                		"gyY REAL, " +
                		"gyZ REAL, " +  
                		"proximityTimestamp LONG," +
                		"proximity REAL, " +
                		"tempTimestamp LONG, " +
                		"temperature REAL, " +
                		"lightTimestamp LONG, " +
                		"illumination TEXT, " +
                		"lux REAL, " +
                		"soundTimestamp LONG, " +
                		"noiseLevel TEXT, " +
                		"soundLevel REAL, " +  
                		"withPeople TEXT, " +
                		"travelledOutside TEXT);");   
              // db.close();
                Log.i(tag, "Database opened ok");
       }

        public void shutdownLoggerService() 
        {             
                stopSoundEngine();
                stopMonitors();
                stopSensors();    
                db.close();
        }                   

        // Below is the service framework methods

        private NotificationManager mNM;

        @Override
        public void onCreate() {
                super.onCreate();
                mNM = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);     
                userActivity = PreferenceManager.getDefaultSharedPreferences(this);
                startLoggerService();
               // showNotification();
            	
        }        
        

     /*   @Override
		public void onStart(Intent intent, int startId) {
			// TODO Auto-generated method stub
        	
			super.onStart(intent, startId);
			updateLabels();
			
		}*/
                
        @Override
		public int onStartCommand(Intent intent, int flags, int startId) {
			
			return super.onStartCommand(intent, flags, startId);
			
		}

		public static void updateLabels()
        {
        	
    		activity = userActivity.getString("activity", "activity");
    		locationLabel = userActivity.getString("location", "location");
    		activityName = userActivity.getString("timeStamp", "activityTimestamp");  
    		withPeople = userActivity.getString("withPeople", "");
    		travelledOutside = userActivity.getString("travelled", "");
    		illumination = userActivity.getString("illumination", "");
    		noiseLevel = userActivity.getString("noise", "");
    		//editor.putString("travelled", userTravelledOutsideCountry);
        }

		@Override
        public void onDestroy() {       
                
                
                // Cancel the persistent notification.
                mNM.cancel(R.string.local_service_started);
               // stopSensors();

                // Tell the user we stopped.
                Toast.makeText(this, R.string.local_service_stopped,Toast.LENGTH_SHORT).show();              
                
                if (BuildConfig.DEBUG)
                {
                    Log.d(tag, "onPause");
                    Log.d(tag, "Unregistering listener");
                }
                
                shutdownLoggerService();
                super.onDestroy();   
            }  
        protected void onPause()
        {
        	shutdownLoggerService() ;
        }
        public static void insertActivity()
        {
        	Location location = LocationMonitor.getCurrentLocation();
        	if(location!=null){
        	String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
       
        	point.setLocation(locationLabel);
        	point.setActivity(activity );
        	point.setLatitude(location.getLatitude());
        	point.setLongitude(location.getLongitude());
        	point.setAltitude(location.getAltitude());
        	point.setBearing(location.getBearing());
        	point.setAccuracy(location.getAccuracy());  
        	point.setSpeed(location.getSpeed());
        	point.setTimeStamp(timeStamp);
        	point.setAcceTimestamp(acceTimestamp);
        	point.setAccX(accX);
        	point.setAccY(accY);
        	point.setAccZ(accZ);
        	point.setAccele(accele);
        	point.setOrientationTimestamp(orientationTimestamp);
        	point.setOrX(orX);
        	point.setOrY(orY);
        	point.setOrZ(orZ);
        	//point.setOrient(orient);
        	point.setLightTimestamp(lightTimestamp);
        	point.setLux(lux);
        	point.setRotationTimestamp(rotationTimestamp);
        	point.setrX(rX);
        	point.setrY(rY);
        	point.setrZ(rZ);        	
        	point.setGravityTimestamp(gravityTimestamp);
        	point.setgX(gX);
        	point.setgY(gY);
        	point.setgZ(gZ);
        	point.setGyroTimestamp(gyroTimestamp);
        	point.setGyX(gyX);
        	point.setGyY(gyY);
        	point.setGyZ(gyZ);
        	//point.setGrav(grav);
        	point.setLinearAcceTimestamp(linearAcceTimestamp);
        	point.setLaccX(laccX);
        	point.setLaccY(laccY);
        	point.setLaccZ(laccZ);
        	point.setLinear(linear);
        	point.setMagTimestamp(magTimestamp);
        	point.setmX(mX);
        	point.setmY(mY);
        	point.setmZ(mZ);
        	//point.setMag(mag);
        	point.setProximityTimestamp(proximityTimestamp);
        	point.setProximity(proximity);
        	point.setAcceTimestamp(acceTimestamp);
        	point.setTempTimestamp(tempTimestamp);
        	point.setTemperature(temperature);
        	point.setSoundTimestamp(soundTimestamp);
        	point.setSoundpressure(soundpressure);
        	point.setWithPeople(withPeople);
        	point.setTravelledOutside(travelledOutside);
        	point.setIllumination(illumination);
        	point.setNoiseLevel(noiseLevel);
        	//point.setTime(timeStamp);
        	//dbManager.insertPoint(point);
        	}
        	else{
        		return;
        	}
        }
        
        public static   void  insertPoint()//COLUMN_TIME
        {
        	
        	updateLabels();
            ContentValues contentValues = new ContentValues();
            contentValues.put(COLUMN_TIME, point.getTimeStamp());
            contentValues.put(COLUMN_LOCATION_LABEL, locationLabel);          
            contentValues.put(COLUMN_LATITUDE, point.getLatitude());
            contentValues.put(COLUMN_LONGITUDE, point.getLongitude());
            contentValues.put(COLUMN_ACCURACY, point.getAccuracy());    
            contentValues.put(COLUMN_ALTITUDE, point.getAltitude());
            contentValues.put(COLUMN_BEARING, point.getBearing());
            contentValues.put(COLUMN_SPEED, point.getSpeed());
            contentValues.put(COLUMN_ORIENTTIME, point.getOrientationTimestamp());
            contentValues.put(COLUMN_ORX, point.getOrX());
            contentValues.put(COLUMN_ORY, point.getOrY());
            contentValues.put(COLUMN_ORZ, point.getOrZ());
            //contentValues.put(COLUMN_OR, point.getOrient());
            contentValues.put(COLUMN_ROTATIONTIME, point.getRotationTimestamp());
            contentValues.put(COLUMN_RX, point.getrX());
            contentValues.put(COLUMN_RY, point.getrY());
            contentValues.put(COLUMN_RZ, point.getrZ());
            //contentValues.put(COLUMN_R, point.getRotate());
            contentValues.put(COLUMN_ACCETIME, point.getAcceTimestamp());
            contentValues.put(COLUMN_ACCX , point.getAccX());
            contentValues.put(COLUMN_ACCY, point.getAccY());
            contentValues.put(COLUMN_ACCZ, point.getAccZ());
            contentValues.put(COLUMN_ACC, point.getAccele());
            contentValues.put(COLUMN_LINEARACCETIME, point.getLinearAcceTimestamp());
            contentValues.put(COLUMN_LACCX , point.getLaccX());
            contentValues.put(COLUMN_LACCY, point.getLaccY());
            contentValues.put(COLUMN_LACCZ, point.getLaccZ());  
            contentValues.put(COLUMN_LACC, point.getLinear());
            contentValues.put(COLUMN_GRAVITYTIME, point.getGravityTimestamp());
            contentValues.put(COLUMN_GX , point.getgX());
            contentValues.put(COLUMN_GY , point.getgY());
            contentValues.put(COLUMN_GZ , point.getgZ());
            contentValues.put(COLUMN_GYROTIME, point.getGyroTimestamp());
            contentValues.put(COLUMN_GYX , point.getGyX());
            contentValues.put(COLUMN_GYY , point.getGyY());
            contentValues.put(COLUMN_GYZ , point.getGyZ());
           // contentValues.put(COLUMN_G , point.getGrav());
            contentValues.put(COLUMN_MAGTIME, point.getMagTimestamp());
            contentValues.put(COLUMN_MX , point.getmX());
            contentValues.put(COLUMN_MY , point.getmY());
            contentValues.put(COLUMN_MZ , point.getmZ());
            //contentValues.put(COLUMN_M , point.getMag());
            contentValues.put( COLUMN_PROXITIME , point.getProximityTimestamp());
            contentValues.put(COLUMN_PROXIMITY , point.getProximity());
            contentValues.put(COLUMN_TEMPTIME, point.getTempTimestamp());
            contentValues.put(COLUMN_TEMPERATURE, point.getTemperature());
            contentValues.put(COLUMN_LIGHTTIME, point.getLightTimestamp());
            contentValues.put(COLUMN_ILLUMINATION, point.getLux());
            contentValues.put(COLUMN_SOUNDTIME, point.getSoundTimestamp());
            contentValues.put(COLUMN_NOISE, point.getSoundpressure());
            contentValues.put(COLUMN_WITH_PEOPLE, withPeople);
            contentValues.put(COLUMN_TRAVEL, travelledOutside); 
           // contentValues.put(COLUMN_PROVIDER, point.getProvider()); 
            contentValues.put(ILLUMINATION_LABEL, illumination); 
            contentValues.put(NOISE_LEVEL, noiseLevel); 
            contentValues.put(COLUMN_ACTIVITY, activity);
            db.insert(ACTIVITY_TABLE_NAME , null, contentValues);
           // db.close();
        }     

      
        private void showNotification() {
              
                CharSequence text = getText(R.string.local_service_started);

              
                Notification notification = new Notification(R.drawable.datalogger,text, System.currentTimeMillis());

             
                PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
                                new Intent(this, ContextDataService.class), 0);

                           
                mNM.notify(R.string.local_service_started, notification);
        }
        
        private final IBinder mBinder = new LocalBinder();

        @Override
        public IBinder onBind(Intent intent) {
                return mBinder;
        }

        public static void setMinTimeMillis(long _minTimeMillis) {
                minTimeMillis = _minTimeMillis;
        }

        public static long getMinTimeMillis() {
                return minTimeMillis;
        }

        public static void setMinDistanceMeters(long _minDistanceMeters) {
                minDistanceMeters = _minDistanceMeters;
        }

        public static long getMinDistanceMeters() {
                return minDistanceMeters;
        }

        public static float getMinAccuracyMeters() {
                return minAccuracyMeters;
        }
        
        public static void setMinAccuracyMeters(float minAccuracyMeters) {
        	ContextDataService.minAccuracyMeters = minAccuracyMeters;
        }

        public static void setShowingDebugToast(boolean showingDebugToast) {
        	ContextDataService.showingDebugToast = showingDebugToast;
        }

        public static boolean isShowingDebugToast() {
                return showingDebugToast;
        }
        
        public void refreshLocation()
        {
        	location = LocationMonitor.getCurrentLocation();
        }
     
        public class LocalBinder extends Binder {
        	ContextDataService getService() {
                        return ContextDataService.this;
                }
        }        
       
	@Override
	public void onSensorChanged(SensorEvent event) {
		  //HighPassUtil highpassfilter = new HighPassUtil();
		 onAccuracyChanged(event.sensor, event.accuracy);
		 
		 
		 switch (event.sensor.getType())
	        {
		 
	            case Sensor.TYPE_ACCELEROMETER:
	            	
	            	float[] values = event.values.clone();
	            	
	            	accele = acceleration(values);
	            	
	            	acceTimestamp =  TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis());
	                
	                accX =  values[0];
	                
	                accY =  values[1];
	                
	                accZ =  values[2];
	                
	                
	                //point.setAccY(accY);
	                Log.i(tag, "Accelerometer: [" + accX+ "]" +" [" + accY+ "]"+" [" + accZ+ "]");
	                break;
	            //Orientation Sensor    
	            case Sensor.TYPE_ORIENTATION:
	            	
	            	orientationTimestamp = TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis());
	            	//orient = acceleration(event.values);
	            	orX = event.values[0];	            
	            	orY = event.values[1];	            	
	            	orZ = event.values[2];
	            	
	            	 Log.i(tag, "Orientation: [" + orX+ "]" +" [" + orY+ "]"+" [" + orZ+ "]");	            	
	            	break;
	            	//Rotation Sensor
	            case Sensor.TYPE_ROTATION_VECTOR: 
	            	rotationTimestamp = TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis());
	            	
	            	//rotate = acceleration(event.values);
                    rX =  event.values[0];
                    rY =  event.values[1];
                    rZ =  event.values[2];
                	Log.i(tag, "ROTATION VECTOR: [" + rX+ "]" +" [" + rY+ "]"+" [" + rZ+ "]");
                	break;
                	//
                	
                	//Gravity Sensor
	            case Sensor.TYPE_GRAVITY:
	            	gravityTimestamp = TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis());
	            	//grav = acceleration(event.values);
                    gX =  event.values[0];
                    gY =  event.values[1];
                    gZ =  event.values[2];
                	Log.i(tag, "Gravity: [" + gX+ "]" +" [" + gY+ "]"+" [" + gZ+ "]");
                	break;
                //Magnetic Sensor	
	            case Sensor.TYPE_MAGNETIC_FIELD:       	
	            	magTimestamp = TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis());
	            	//mag = acceleration(event.values);
                    mX =  event.values[0];
                    mY =  event.values[1];
                    mZ =  event.values[2];
                	Log.i(tag, "Magnetic Field: [" + mX+ "]" +" [" + mY+ "]"+" [" + mZ+ "]");
                	break;
	            //Linear Accelerometer	
	            case Sensor.TYPE_LINEAR_ACCELERATION:
	            	linearAcceTimestamp = TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis());	            	
	            	//float[] values = event.values.clone();
	            	linear = acceleration(event.values);
	            	 laccX =  event.values[0];		                
		             laccY =  event.values[1];		                
		             laccZ =  event.values[2];
		                //point.setAccY(accY);
		            Log.i(tag, "Linear Accelerometer: [" + laccX+ "]" +" [" + laccY+ "]"+" [" + laccZ+ "]");
		            break;
		            
	            case Sensor.TYPE_GYROSCOPE:
	            	gyroTimestamp = TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis());
	            	gyX = event.values[0];
	            	gyY = event.values[1];
	            	gyZ = event.values[2];
	            	Log.i(tag, " Gyroscope: [" + gyX+ "]" +" [" + gyY+ "]"+" [" + gyZ+ "]");
	            case Sensor.TYPE_LIGHT:
	            	lightTimestamp = TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis());
	            	lux = event.values[0];	            	
	            	Log.i(tag, "Illumination: [" + lux + "]");
	            	break;	            	
	            case Sensor.TYPE_PROXIMITY:
	            	proximityTimestamp =TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis());	            	
	            	proximity = event.values[0];	            
	            	Log.i(tag,"Proximity:+ [" + proximity+ "]");
	            	break;	          
	            case Sensor.TYPE_TEMPERATURE:
	            	tempTimestamp =TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis());	            	
	            	temperature =  event.values[0];	            	
	            	Log.i(tag, "Temperature: [" + temperature+ "]");
	            	break;	         	
	        }		
		 		 	//insertPoint();
	}	
		  public Handler mhandle = new Handler() {
	         @Override
	         public void handleMessage(Message msg) {
	                 switch (msg.what) {
	                         case MY_MSG :
	                             soundTimestamp = TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis());
	                        	 soundpressure = (Double) msg.obj;
	                        	Log.i(tag, msg.toString());
	                                 break;
	                                 
	                         case ERROR_MSG:
	                                 Toast.makeText(
	                                                 mContext, 
	                                                 "Error " + msg.obj, Toast.LENGTH_LONG).show();
	                                 stopSoundEngine();
	                                 break;
	                        
	                         default :
	                                 super.handleMessage(msg);
	                                 break;
	                 }
	         }

	 };
	 
	 public void stopSoundEngine()
	 {
		 noiseLevelSensor.stop_engine();
	 }
	 		  public void startSoundEngine()
			 {
			  noiseLevelSensor = new NoiseSensor(mhandle, mContext);
			  noiseLevelSensor.start_engine();
			 }
 
	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {
		 switch(accuracy)
	       {
	           case SensorManager.SENSOR_STATUS_ACCURACY_HIGH:
	        	   
	               this.accuracy = "SENSOR_STATUS_ACCURACY_HIGH";
	               break;
	           case SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM:
	               this.accuracy = "SENSOR_STATUS_ACCURACY_MEDIUM";
	               break;
	           case SensorManager.SENSOR_STATUS_ACCURACY_LOW:
	               this.accuracy = "SENSOR_STATUS_ACCURACY_LOW";
	               break;
	           case SensorManager.SENSOR_STATUS_UNRELIABLE:
	               this.accuracy  = "SENSOR_STATUS_UNRELIABLE";
	               break;
	       }
	}
		
	public float lowPassFilter(float current, float last)
	{
		float a = 10f;
		return last*(1.0f -a) + current*a;
	}
			  
	public void startMonitors() {

		 	Intent intent = null;
	
			intent = new Intent(this, org.com.context.GPSService.class);
			startService(intent);
			Log.i(tag,"Started GPS");
			/* Start Network Service */
			intent = new Intent(this, org.com.context.NetworkService.class);
			startService(intent);
			Log.i(tag,"Started Network Location Service");
			
			LocationMonitor.StartThread(locationPollFreq);		  
		}
	
	private void stopMonitors() {
		
		stopService(new Intent(this, org.com.context.GPSService.class));
		Log.i(tag,"Started GPS");		
		stopService(new Intent(this, org.com.context.NetworkService.class));
		LocationMonitor.StopThread();
			
		}
	
	public void startSensors(){			
			// make sure not to call it twice
			sm = (SensorManager) getSystemService(SENSOR_SERVICE);
			List<Sensor> acce_sensors = sm.getSensorList(Sensor.TYPE_ACCELEROMETER);
			if (acce_sensors != null && acce_sensors.size() > 0) {
				accelerometerSensor = acce_sensors.get(0);
				
				switch (accelPeriod) {
				case 4:
					sm.registerListener((SensorEventListener)this, accelerometerSensor, SensorManager.SENSOR_DELAY_FASTEST);
					break;
				case 3:
					sm.registerListener((SensorEventListener)this, accelerometerSensor, SensorManager.SENSOR_DELAY_GAME);
					break;
				case 2:
					sm.registerListener((SensorEventListener)this, accelerometerSensor, SensorManager.SENSOR_DELAY_NORMAL);
					break;
				case 1:
				default:
					sm.registerListener((SensorEventListener)this, accelerometerSensor, SensorManager.SENSOR_DELAY_UI);
					break;
				}
				accelerometerSensorsEnabled = true;
			} else {
				Toast.makeText(this, "Accelerometer sensor is not available on this device!", Toast.LENGTH_SHORT).show();
			}
			
					List<Sensor> orient_sensors = sm.getSensorList(Sensor.TYPE_ORIENTATION);
			if (orient_sensors != null && orient_sensors.size() > 0) {
				orientationSensor = orient_sensors.get(0);
				
				switch (accelPeriod) {
				case 4:
					sm.registerListener((SensorEventListener)this, orientationSensor, SensorManager.SENSOR_DELAY_FASTEST);
					break;
				case 3:
					sm.registerListener((SensorEventListener)this, orientationSensor, SensorManager.SENSOR_DELAY_GAME);
					break;
				case 2:
					sm.registerListener((SensorEventListener)this, orientationSensor, SensorManager.SENSOR_DELAY_NORMAL);
					break;
				case 1:
				default:
					sm.registerListener((SensorEventListener)this, orientationSensor, SensorManager.SENSOR_DELAY_UI);
					break;
				}
				orientationSensorsEnabled = true;
			} else {
				Toast.makeText(this, "Orientation sensor is not available on this device!", Toast.LENGTH_SHORT).show();
			}
			
			List<Sensor> temp_sensors = sm.getSensorList(Sensor.TYPE_TEMPERATURE);
			if (temp_sensors != null && temp_sensors.size() > 0) {
				temperatureSensor = temp_sensors.get(0);
				
				switch (accelPeriod) {
				case 4:
					sm.registerListener((SensorEventListener)this, temperatureSensor, SensorManager.SENSOR_DELAY_FASTEST);
					break;
				case 3:
					sm.registerListener((SensorEventListener)this, temperatureSensor, SensorManager.SENSOR_DELAY_GAME);
					break;
				case 2:
					sm.registerListener((SensorEventListener)this, temperatureSensor, SensorManager.SENSOR_DELAY_NORMAL);
					break;
				case 1:
				default:
					sm.registerListener((SensorEventListener)this, temperatureSensor, SensorManager.SENSOR_DELAY_UI);
					break;
				}
				tempSensorsEnabled = true;
			} else {
				Toast.makeText(this, "Temperature sensor is not available on this device!", Toast.LENGTH_SHORT).show();
			}
			
			List<Sensor> light_sensors = sm.getSensorList(Sensor.TYPE_LIGHT);
			if (light_sensors != null && light_sensors.size() > 0) {
				lightSensor = light_sensors.get(0);
				
				switch (accelPeriod) {
				case 4:
					sm.registerListener((SensorEventListener)this, lightSensor, SensorManager.SENSOR_DELAY_FASTEST);
					break;
				case 3:
					sm.registerListener((SensorEventListener)this, lightSensor, SensorManager.SENSOR_DELAY_GAME);
					break;
				case 2:
					sm.registerListener((SensorEventListener)this, lightSensor, SensorManager.SENSOR_DELAY_NORMAL);
					break;
				case 1:
				default:
					sm.registerListener((SensorEventListener)this, lightSensor, SensorManager.SENSOR_DELAY_UI);
					break;
				}
				lightSensorsEnabled = true;
			} else {
				Toast.makeText(this, "Light sensor is not available on this device!", Toast.LENGTH_SHORT).show();
			}
			List<Sensor> proximity_sensors = sm.getSensorList(Sensor.TYPE_PROXIMITY);
			if (proximity_sensors != null && proximity_sensors.size() > 0) {
				proximitySensor = proximity_sensors.get(0);
				
				switch (accelPeriod) {
				case 4:
					sm.registerListener((SensorEventListener)this, proximitySensor, SensorManager.SENSOR_DELAY_FASTEST);
					break;
				case 3:
					sm.registerListener((SensorEventListener)this, proximitySensor, SensorManager.SENSOR_DELAY_GAME);
					break;
				case 2:
					sm.registerListener((SensorEventListener)this, proximitySensor, SensorManager.SENSOR_DELAY_NORMAL);
					break;
				case 1:
				default:
					sm.registerListener((SensorEventListener)this, proximitySensor, SensorManager.SENSOR_DELAY_UI);
					break;
				}
				proximitySensorsEnabled = true;
			} else {
				Toast.makeText(this, "Light sensor is not available on this device!", Toast.LENGTH_SHORT).show();
			}
			List<Sensor> gravity_sensors = sm.getSensorList(Sensor.TYPE_GRAVITY);
			if (gravity_sensors != null && gravity_sensors.size() > 0) {
				gravity = gravity_sensors.get(0);
				
				switch (accelPeriod) {
				case 4:
					sm.registerListener((SensorEventListener)this, gravity, SensorManager.SENSOR_DELAY_FASTEST);
					break;
				case 3:
					sm.registerListener((SensorEventListener)this, gravity, SensorManager.SENSOR_DELAY_GAME);
					break;
				case 2:
					sm.registerListener((SensorEventListener)this, gravity, SensorManager.SENSOR_DELAY_NORMAL);
					break;
				case 1:
				default:
					sm.registerListener((SensorEventListener)this, gravity, SensorManager.SENSOR_DELAY_UI);
					break;
				}
				gravitySensorsEnabled = true;
			} else {
				Toast.makeText(this, "Gravity sensor is not available on this device!", Toast.LENGTH_SHORT).show();
			}
			List<Sensor> gyroscope_sensors = sm.getSensorList(Sensor.TYPE_GYROSCOPE);
			if (gyroscope_sensors != null && gravity_sensors.size() > 0) {
				gyroscope = gyroscope_sensors.get(0);
				
				switch (accelPeriod) {
				case 4:
					sm.registerListener(this, gyroscope, SensorManager.SENSOR_DELAY_FASTEST);
					break;
				case 3:
					sm.registerListener(this, gyroscope, SensorManager.SENSOR_DELAY_GAME);
					break;
				case 2:
					sm.registerListener(this, gyroscope, SensorManager.SENSOR_DELAY_NORMAL);
					break;
				case 1:
				default:
					sm.registerListener(this, gyroscope, SensorManager.SENSOR_DELAY_UI);
					break;
				}
				gyroscopeSensorsEnabled = true;
			} else {
				Toast.makeText(this, "Gyroscope sensor is not available on this device!", Toast.LENGTH_SHORT).show();
			}
			List<Sensor> linearAccelerometers = sm.getSensorList(Sensor.TYPE_LINEAR_ACCELERATION);
			if (linearAccelerometers != null && linearAccelerometers.size() > 0) {
				linearAccelerometer = linearAccelerometers.get(0);
				
				switch (accelPeriod) {
				case 4:
					sm.registerListener((SensorEventListener)this, linearAccelerometer, SensorManager.SENSOR_DELAY_FASTEST);
					break;
				case 3:
					sm.registerListener((SensorEventListener)this, linearAccelerometer, SensorManager.SENSOR_DELAY_GAME);
					break;
				case 2:
					sm.registerListener((SensorEventListener)this, linearAccelerometer, SensorManager.SENSOR_DELAY_NORMAL);
					break;
				case 1:
				default:
					sm.registerListener((SensorEventListener)this, linearAccelerometer, SensorManager.SENSOR_DELAY_UI);
					break;
				}
				linearAccelerometerSensorsEnabled = true;
			} else {
				Toast.makeText(this, "LinearAccelerometer sensor is not available on this device!", Toast.LENGTH_SHORT).show();
			}
			List<Sensor> rotationSensors = sm.getSensorList(Sensor.TYPE_ROTATION_VECTOR);
			if (rotationSensors != null && rotationSensors.size() > 0) {
				rotationSensor = rotationSensors.get(0);
				
				switch (accelPeriod) {
				case 4:
					sm.registerListener((SensorEventListener)this, rotationSensor, SensorManager.SENSOR_DELAY_FASTEST);
					break;
				case 3:
					sm.registerListener((SensorEventListener)this, rotationSensor, SensorManager.SENSOR_DELAY_GAME);
					break;
				case 2:
					sm.registerListener((SensorEventListener)this, rotationSensor, SensorManager.SENSOR_DELAY_NORMAL);
					break;
				case 1:
				default:
					sm.registerListener((SensorEventListener)this, rotationSensor, SensorManager.SENSOR_DELAY_UI);
					break;
				}
				rotationSensorsEnabled = true;
			} else {
				Toast.makeText(this, "Rotation sensor is not available on this device!", Toast.LENGTH_SHORT).show();
			}
			
			List<Sensor> magneticFieldSensors = sm.getSensorList(Sensor.TYPE_MAGNETIC_FIELD);
			if (magneticFieldSensors != null && magneticFieldSensors.size() > 0) {
				magneticField = magneticFieldSensors.get(0);
				
				switch (accelPeriod) {
				case 4:
					sm.registerListener((SensorEventListener)this, magneticField, SensorManager.SENSOR_DELAY_FASTEST);
					break;
				case 3:
					sm.registerListener((SensorEventListener)this, magneticField, SensorManager.SENSOR_DELAY_GAME);
					break;
				case 2:
					sm.registerListener((SensorEventListener)this, magneticField, SensorManager.SENSOR_DELAY_NORMAL);
					break;
				case 1:
				default:
					sm.registerListener((SensorEventListener)this, magneticField, SensorManager.SENSOR_DELAY_UI);
					break;
				}
				magneticFieldSensorsEnabled = true;
			} else {
				Toast.makeText(this, "Magnetic Field sensor is not available on this device!", Toast.LENGTH_SHORT).show();
			}


			IntentFilter restartFilter = new IntentFilter();
			restartFilter.addAction(CONTEXT_RESTART_INTENT);
			registerReceiver(restartIntentReceiver, restartFilter);
		}
	
	BroadcastReceiver restartIntentReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			if (DEBUG) {
				Log.d(TAG, TAG + "Restart Intent: " + intent.getAction());
			}
			if (proximitySensorsEnabled&&lightSensorsEnabled&&tempSensorsEnabled&&accelerometerSensorsEnabled&&lightSensorsEnabled&&orientationSensorsEnabled
					
					&&linearAccelerometerSensorsEnabled&&rotationSensorsEnabled&&magneticFieldSensorsEnabled) {
				stopSensors();
				running = false;
			}
			startSensors();
			running = true;
		}
	};
	
	public void stopSensors()		{
		
		releaseSensors();
		unregisterReceiver(restartIntentReceiver);
		running = false;		
	}
	
	public void releaseSensors()
	{
		sm.unregisterListener((SensorEventListener)this,magneticField);
		sm.unregisterListener((SensorEventListener)this,rotationSensor);
		sm.unregisterListener((SensorEventListener)this,linearAccelerometer);
		sm.unregisterListener((SensorEventListener)this,gravity);
		sm.unregisterListener((SensorEventListener) this, gyroscope);
		sm.unregisterListener((SensorEventListener)this,proximitySensor);
		sm.unregisterListener((SensorEventListener)this,lightSensor);
		sm.unregisterListener((SensorEventListener)this,temperatureSensor);
		sm.unregisterListener((SensorEventListener)this,orientationSensor);
		sm.unregisterListener((SensorEventListener)this,accelerometerSensor);
	}
	
	public float[] highPass(float x, float y, float z)
    {
        float[] filteredValues = new float[3];
        
        reading[0] = ALPHA * reading[0] + (1 - ALPHA) * x;
        reading[1] = ALPHA * reading[1] + (1 - ALPHA) * y;
        reading[2] = ALPHA * reading[2] + (1 - ALPHA) * z;

        filteredValues[0] = x - reading[0];
        filteredValues[1] = y - reading[1];
        filteredValues[2] = z - reading[2];
        
        return filteredValues;
    }
	
	public double acceleration(float[]values)
	{
		double sumOfSquares = (values[0] * values[0])
	            + (values[1] * values[1])
	            + (values[2] * values[2]);
	    double acceleration = Math.sqrt(sumOfSquares);
	    return acceleration;
	}

	
}
	
