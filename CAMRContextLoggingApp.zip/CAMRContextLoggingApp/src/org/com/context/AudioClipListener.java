package org.com.context;

public interface AudioClipListener
{
    public boolean heard(short [] audioData, int sampleRate);
}
