package org.com.context;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.util.Log;

public class LocationMonitor extends TimerTask {
	private static final String TAG = "LocationMonitor";
	private static final long radiusOfEarthMeters = 6378100;
	private static boolean running = false;
	private static Timer timer = new Timer();

	private static LocationMonitor locationObj = new LocationMonitor();
	private static Location currentLocation = new Location(new String());
	private static Geocoder geocoder = null;

	public static final String LATITUDE_INTENT_KEY = "LATITUDE_INTENT_KEY";
    public static final String LONGITUDE_INTENT_KEY = "LONGITUDE_INTENT_KEY";
    public static final String RADIUS_INTENT_KEY = "RADIUS_INTENT_KEY";
  
	private static HashMap<String, Address> proximityAddressCache = new HashMap<String, Address>();

	public static void StartThread(int interval) {
		if (running == true) {
			return;
		}
		Log.i(TAG, "Start()");
		timer.schedule(locationObj, 100, interval*1000);
		running = true;
		
	}

	public static void StopThread() {
		Log.i(TAG, "Stop()");
		//GPSService.
		timer.purge();
		locationObj = new LocationMonitor();
		running = false;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		updateLocation();
				//updateYahooLocation();
				Log.i(TAG, "Location: [" + currentLocation + "]");
				Log.i(TAG, "GPSLocation: [" + GPSService.getLocation() + "]");
			}

			public static double proximityTo(String loc) {
				Address tmpAddress = null;
				Address address = null;			
				
				if ((tmpAddress = proximityAddressCache.get(loc)) != null) {
					address = tmpAddress;
				} else {
			
					address = getGeoFromAddress(loc);
					if (address == null) {
						Log.i(TAG, "proximityTo() could not convert [" + loc + "]");
						return -1.0;
					} else {
					
						proximityAddressCache.put(loc, address);
					}
				}

				return distanceMeters(address.getLatitude(), address.getLongitude(), getLatitude(), getLongitude());
	}

	public static double proximityTo(double longitude, double latitude) {
		return distanceMeters(latitude, longitude, getLatitude(), getLongitude());
	}

	public static boolean isInside() {
		if (GPSService.isReliable() == false) {
			return true;
		}
		return false;
	}
	
	
	public static double getLongitude() {
		if (GPSService.isReliable() == true) {
			return GPSService.getLongitude();
		
		}
		return 0;
	}

	public static double getLatitude() {
		if (GPSService.isReliable() == true) {
			return GPSService.getLatitude();
	
		}
		return 0;
	}
		

	public static double getAltitude() {
		if (GPSService.isReliable() == true) {
			return GPSService.getAltitude();
		
		}
		return 0;
	}

	public static float getBearing() {
		if (GPSService.isReliable() == true) {
			return GPSService.getBearing();
		} 
		return 0;
	}
	
	public static float getSpeed() {
		if (GPSService.isReliable() == true) {
			return GPSService.getSpeed();
		} 
		return 0;
	}
	public static Location getLocation() {
		if (GPSService.getLocation()!=null) {
			return GPSService.getLocation();
		} else if (NetworkService.getLocation()!=null) {
			return NetworkService.getLocation();
		}
		return null;
	}
	
	public void updateLocation()
	{
		currentLocation = getLocation();
	}
	private static Address getGeoFromAddress(String str) {
		List<Address> addresses = null;
		Address address = null;
		try {
			addresses = geocoder.getFromLocationName(str, 1);
			if (addresses == null) {
				Log.i(TAG, "getGeoFromAddress(): " + addresses);
				return null;
			}
			if (addresses.size() > 0) {
				address =  addresses.get(0);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return address;
	}

	
	//41.180037, -8.5952032  getLatitude()getLongitude()
	
	public static double milesPerHourToMetersPerSecond(double milesPerHour) {
		return 0.44704 * milesPerHour;
	}

	public static double distanceMeters(double aLat, double aLon, double bLat, double bLon) {
	// Haversine formula for calculating distance from GPS coordinates: from http://mathforum.org/library/drmath/view/51879.html
		double dlon = bLon - aLon;
		double dlat = bLat - aLat;
		double a = Math.pow(Math.sin(Math.toRadians(dlat/2)), 2) +
		Math.cos(Math.toRadians(aLat)) *
		Math.cos(Math.toRadians(bLat)) *
		Math.pow(Math.sin(Math.toRadians(dlon / 2)), 2);
		double greatCircleDistance = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
		return radiusOfEarthMeters * greatCircleDistance;
	}	
	
		public static Location getCurrentLocation() {
		return currentLocation;
	}

	public static void setCurrentLocation(Location currentLocation) {
		LocationMonitor.currentLocation = currentLocation;
	}
	
}
