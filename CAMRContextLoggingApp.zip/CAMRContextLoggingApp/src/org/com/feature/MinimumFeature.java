package org.com.feature;

public class MinimumFeature extends SingleSeriesFeature {

    public MinimumFeature(int series) {
        super(series);
    }

    @Override
    protected String getFeatureName() {
        return "Minimum";
    }

    @Override
    protected float getValue(float[] values) {
        float min = Float.MAX_VALUE;

        for (float value : values) {
            min = Math.min(min, value);
        }

        return min;
    }

}
