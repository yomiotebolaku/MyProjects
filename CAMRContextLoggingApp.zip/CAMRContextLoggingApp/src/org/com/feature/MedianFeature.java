package org.com.feature;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MedianFeature extends SingleSeriesFeature {

    public MedianFeature(int series) {
        super(series);
    }

    @Override
    protected String getFeatureName() {
        return "Median";
    }

    @Override
    protected float getValue(float[] values) {
        final List<Float> newValues = new ArrayList<Float>(values.length);

        for (float value : values) {
            newValues.add(value);
        }

        Collections.sort(newValues);

        return newValues.get(newValues.size() / 2);
    }

}
