package org.com.feature;

public class MaximumFeature extends SingleSeriesFeature {

    public MaximumFeature(int series) {
        super(series);
    }

    @Override
    protected String getFeatureName() {
        return "Maximum";
    }

    @Override
    protected float getValue(float[] values) {
        float max = Float.MIN_VALUE;

        for (float value : values) {
            max = Math.max(max, value);
        }

        return max;
    }

}
