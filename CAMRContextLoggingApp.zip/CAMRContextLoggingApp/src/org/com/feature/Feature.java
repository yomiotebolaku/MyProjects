package org.com.feature;

public interface Feature {

    String getName();

    float getValue(final Window window);

}
