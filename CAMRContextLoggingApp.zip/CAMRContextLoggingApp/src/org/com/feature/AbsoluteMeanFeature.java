package org.com.feature;

public class AbsoluteMeanFeature extends SingleSeriesFeature {

    public AbsoluteMeanFeature(int series) {
        super(series);
    }

    @Override
    protected String getFeatureName() {
        return "Absolute Mean";
    }

    @Override
    protected float getValue(float[] values) {
        float total = 0;

        for (float value : values) {
            total += value;
        }

        return Math.abs(total / values.length);
    }

}
